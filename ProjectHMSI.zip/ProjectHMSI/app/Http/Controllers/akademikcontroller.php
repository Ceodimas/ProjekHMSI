<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\hmsi;

class akademikcontroller extends Controller
{
    //
    public function index()
    {

        
        return view('hmsi.akademik');
    }

 

}


