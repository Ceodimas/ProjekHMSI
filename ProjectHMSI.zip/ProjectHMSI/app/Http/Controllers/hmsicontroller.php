<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\hmsi;

class hmsicontroller extends Controller
{
    //
    public function index()
    {

        return view('hmsi.hmsi');
    }

 

}


