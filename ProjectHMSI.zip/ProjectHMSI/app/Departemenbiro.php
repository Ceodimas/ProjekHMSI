<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Departemenbiro extends Model
{
    //
}
