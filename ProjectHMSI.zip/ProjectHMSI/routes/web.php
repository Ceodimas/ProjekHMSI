<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
//
 

Route::resource('/hmsi','hmsicontroller');
Route::resource('/kaderisasi','kaderisasicontroller');
Route::resource('/ristek','ristekcontroller');
Route::resource('/kemahasiswaan','kemahasiswaancontroller');
Route::resource('/hrd','hrdcontroller');
Route::resource('/epr','eprcontroller');
Route::resource('/kominfo','kominfocontroller');
Route::resource('/dm','dmcontroller');
Route::resource('/akademik','akademikcontroller');
Route::resource('/relasi','relasicontroller');




 
 

 