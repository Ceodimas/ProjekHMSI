 
    <!DOCTYPE html>
<html>

<!-- Mirrored from t.commonsupport.com/torino/index-2.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 08 Aug 2017 12:39:07 GMT -->
<head>
<meta charset="utf-8">
<title>HMSI | <?php echo $__env->yieldContent('title'); ?></title>
<!-- Stylesheets -->




<link href="<?php echo e(asset('/css/bootstrap.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('/css/revolution-slider.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('/css/jquery-ui.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('/css/style.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('/css/responsive.css')); ?>" rel="stylesheet">



<!--Color Switcher Mockup-->




<!--Color Themes-->
<link href="css/color-themes/blue-theme.css" rel="stylesheet">


<!--Favicon-->
<link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon">
<link rel="icon" href="images/favicon.ico" type="image/x-icon">
<!-- Responsive -->
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
<!--[if lt IE 9]><script src="https://cdnjs.cloudflare.com/ajax/libs/html5shiv/3.7.3/html5shiv.js"></script><![endif]-->
<!--[if lt IE 9]><script src="js/respond.js"></script><![endif]-->
</head>

<body>

<div class="page-wrapper">

    <!-- Preloader -->
    <div class="preloader"></div>

    <!-- Main Header -->
    <header class="main-header header-style-two">
        <!-- Header Top-->
        <div class="header-top style-two">
            <div class="auto-container">
                <div class="clearfix">

                    <!--Top Left-->
                    <div class="top-left top-links">
                        <ul class="clearfix">
                            <li><a href="#"><span class="icon fa fa-globe"></span> hmsi.telkomuniversity.ac.id </a></li>
                            <li><a href="#"><span class="icon fa fa-envelope-o"></span> ristek_hmsi@gmail.com</a></li>
                        </ul>
                    </div>

                    <!--Top Right-->
                    <div class="top-right">
                        <div class="social-icon">
                            <a href="#"><span class="fa fa-facebook"></span></a>
                            <a href="#"><span class="fa fa-twitter"></span></a>
                            <a href="#"><span class="fa fa-google-plus"></span></a>
                            <a href="#"><span class="fa fa-youtube"></span></a>
                            <a href="#"><span class="fa fa-instagram"></span></a>
                        </div>
                    </div>

                </div>

            </div>
        </div>
        <!-- Header Top One End -->

        <!-- Header Lower -->
        <div class="header-lower">
            <div class="main-box">
                <div class="auto-container">
                    <div class="outer-container clearfix">
                        <!--Logo Box-->
                        <div class="logo-box">
                            <div class="logo"><a href="/todo"><img src="images/logo-2.png" alt=""></a></div>
                        </div>

                        <!--Nav Outer-->
                        <div class="nav-outer clearfix">
                            <!-- Main Menu -->
                            <nav class="main-menu">
                                <div class="navbar-header">
                                    <!-- Toggle Button -->
                                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                    </button>
                                </div>

                                <div class="navbar-collapse collapse clearfix">
                                    <ul class="navigation clearfix">


                                        
                                        <li class="dropdown"><a href="/hmsi">HMSI</a>
                                            <ul>
                                                <li><a class="scroll-to-target" href="/hmsi#sejarah">Sejarah</a></li>
                                                <li><a class="scroll-to-target" href="/hmsi#visimisi">Visi dan Misi</a></li>
                                                <li><a class="scroll-to-target" href="/hmsi#strukturorganisasi">Struktur Organisasi</a></li>
                                                <li class="dropdown"><a scroll-to-target" href="/hmsi#departemenbiro">Departement dan Biro</a>
                                                    <ul>
                                                        <li><a href="/kaderisasi">Kaderisasi</a></li>
                                                        <li><a href="/ristek">Riset dan Teknologi</a></li>
                                                        <li><a href="/kemahasiswaan">Kemahasiswaan</a></li>
                                                        <li><a href="/hrd">Human Resources Development</a></li>
                                                        <li><a href="/epr">Enterpreneur</a></li>
                                                        <li><a href="/kominfo">Komunikasi dan Informasi</a></li>
                                                        <li><a href="/akademik">Akademik</a></li>
                                                        <li><a href="/dm">Dedikasi Masyarakat</a></li>
                                                        <li><a href="/relasi">Relasi</a></li>
                                                    </ul>
                                                </li>
                                            </ul>
                                        </li>


                                        <li class=" dropdown"><a href="/laboratorium/beranda">LABORATORIUM</a>
                                            <ul>
                                                <li><a href="/laboratorium/sisjar">SISJAR</a></li>
                                                <li><a href="/laboratorium/prodase">PRODASE</a></li>
                                                <li><a href="/laboratorium/erp">ERP</a></li>
                                                <li><a href="/laboratorium/bpad">BPAD</a></li>
                                            </ul>
                                        </li>

                                        <li class=" dropdown"><a href="/keprofesian/beranda">KEPROFESIAN</a>
                                            <ul>
                                                <li><a href="/keprofesian/elc">ERP Laboratory Club</a></li>
                                                <li><a href="/keprofesian/blc">BPAD Laboratory Club</a></li>
                                            </ul>
                                        </li>


                                        <li class=" dropdown"><a href="/event/beranda">EVENT</a>
                                            <ul>
                                                <li><a href="/event/agenda">AGENDA</a></li>
                                                <li><a href="/event/galery">GALERI</a></li>
                                            </ul>
                                        </li>

                                        <li><a href="/tokohmsi">TOKO HMSI</a></li>


                                        <li><a href="/hubungikami">HUBUNGI KAMI</a></li>
                                     </ul>
                                </div>
                            </nav><!-- Main Menu End-->

                            <!--Button Outer-->
                            <div class="btn-outer">

                                <div class="dropdown">
                                    <button class="search-box-btn dropdown-toggle" type="button" id="dropdownMenu3" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><span class="fa fa-search"></span></button>
                                    <ul class="dropdown-menu pull-right search-panel" aria-labelledby="dropdownMenu3">
                                        <li class="panel-outer">
                                            <div class="form-container">
                                                <form method="post" action="http://t.commonsupport.com/torino/blog.html">
                                                    <div class="form-group">
                                                        <input type="search" name="field-name" value="" placeholder="Search Here" required="">
                                                        <button type="submit" class="search-btn"><span class="fa fa-search"></span></button>
                                                    </div>
                                                </form>
                                            </div>
                                        </li>
                                    </ul>
                                </div>

                                
                            </div>

                        </div><!--Nav Outer End-->

                    </div>
                </div>
            </div>
        </div>

        <!--Sticky Header-->
        <div class="sticky-header">
            <div class="auto-container clearfix">
                <!--Logo-->
                <div class="logo pull-left">
                    <a href="index-2.html" class="img-responsive"><img src="images/logo-small.png" alt="" title=""></a>
                </div>

                <!--Right Col-->
                <div class="right-col pull-right">
                    <!-- Main Menu -->
                    <nav class="main-menu">
                        <div class="navbar-header">
                            <!-- Toggle Button -->
                            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            </button>
                        </div>

                        <div class="navbar-collapse collapse clearfix">
                            <ul class="navigation clearfix">
                                        
                                        <li class="dropdown"><a href="/hmsi">HMSI</a>
                                            <ul>
                                                <li><a class="scroll-to-target" href="/hmsi#sejarah">Sejarah</a></li>
                                                <li><a class="scroll-to-target" href="/hmsi#visimisi">Visi dan Misi</a></li>
                                                <li><a class="scroll-to-target" href="/hmsi#strukturorganisasi">Struktur Organisasi</a></li>
                                                <li class="dropdown"><a scroll-to-target" href="/hmsi#departemenbiro">Departement dan Biro</a>
                                                    <ul>
                                                        <li><a href="/kaderisasi">Kaderisasi</a></li>
                                                        <li><a href="/ristek">Riset dan Teknologi</a></li>
                                                        <li><a href="/kemahasiswaan">Kemahasiswaan</a></li>
                                                        <li><a href="/hrd">Human Resources Development</a></li>
                                                        <li><a href="/epr">Enterpreneur</a></li>
                                                        <li><a href="/kominfo">Komunikasi dan Informasi</a></li>
                                                        <li><a href="/akademik">Akademik</a></li>
                                                        <li><a href="/dm">Dedikasi Masyarakat</a></li>
                                                        <li><a href="/relasi">Relasi</a></li>
                                                    </ul>
                                                </li>
                                            </ul>
                                        </li>


                                        <li class=" dropdown"><a href="/laboratorium/beranda">LABORATORIUM</a>
                                            <ul>
                                                <li><a href="/sisjar">SISJAR</a></li>
                                                <li><a href="/prodase">PRODASE</a></li>
                                                <li><a href="/erp">ERP</a></li>
                                                <li><a href="/bpad">BPAD</a></li>
                                            </ul>
                                        </li>

                                        <li class=" dropdown"><a href="/keprofesian/beranda">KEPROFESIAN</a>
                                            <ul>
                                                <li><a href="/elc">ERP Laboratory Club</a></li>
                                                <li><a href="/blc">BPAD Laboratory Club</a></li>
                                            </ul>
                                        </li>


                                        <li class=" dropdown"><a href="/event/beranda">EVENT</a>
                                            <ul>
                                                <li><a href="/event/agenda">AGENDA</a></li>
                                                <li><a href="/event/galery">GALERI</a></li>
                                            </ul>
                                        </li>

                                        <li><a href="/tokohmsi">TOKO HMSI</a></li>


                                        <li><a href="/hubungikami">HUBUNGI KAMI</a></li>

                             </ul>
                        </div>
                    </nav><!-- Main Menu End-->
                </div>

            </div>
        </div>
        <!--End Sticky Header-->

    </header>
    <!--End Main Header -->

     


    <!--About Section Two-->
    <section class="about-section-two">
    	<div class="auto-container">
        	<div class="row clearfix">
            	<!--Content Column-->
                <div class="content-column col-md-6 col-sm-12 col-xs-12">
                	<div class="inner">
                    	<div class="about-title">
                        	<div class="sub-title">Sambutan Ketua HMSI</div>
                            <h2>Selamat Datang</h2>
                        </div>

                        <div class="text">
                          Selamat datang di Portal HMSI, disini kami sajikan berbagai informasi mengenai apa saja yang ada di dalam jurusan kita, Sistem Informasi.
                          Rubrik seputar event, informasi laboratorium, dan organisasi bisa kalian akses disini.

                        </div>
                         
                    </div>
                </div>
                <!--Video Column-->
                <div class="video-column col-md-6 col-sm-12 col-xs-12">
                	<div class="video-box">
                        <figure class="image">
                            <img src="images/resource/video-img.jpg" alt="">
                        </figure>
                        <a href="https://www.youtube.com/watch?v=QVl-gdg5s94" class="lightbox-image overlay-box"><span class="flaticon-arrow"></span></a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--End About Section Two-->
 

    <!--Sponsors Section-->
    <section id="sejarah" class="sponsors-section"  >
      <div class="auto-container">

          <!--Sec Title-->
            <div class="sec-title centered">
              <h2>Sejarah</h2>
                <h3>HMSI 2017-2018</h3>
                <div class="text" style="text-align: justify;">


                HMSI (Himpunan Mahasiswa Sistem Informasi) Telkom University  yang didirikan pada tanggal Maret 2014 antara lain mempunyai tujuan berperan aktif mewujudkan mahasiswa Sistem Informasi menjadi insan akademis yang  berlandaskan IMTAQ dan IPTEK serta bertanggung jawab dalam mewujudkan Tridarma Perguruan Tinggi dan peningkatan mahasiswa kearah profesi sebagai organisasi penerus bangsa.<br>

                Pada saat ini HMSI sebagai wadah koordinasi kegiatan bagi mahaiswa Sistem Informasi Universitas Telkom harus diarahkan untuk lebih berorientasi pada pengembangan sikap ilmiah dan sikap keahlian (profesionalisme) bagi para mahasiswa. HMSI Unitel dituntut untuk mampu memberikan kontribusi positif dalam rangka pengembangan ilmu pengetahuan dan teknologi khususnya di bidang keilmuan Sistem Informasi dalam kaitannya memecahkan permasalahan bangsa ini.<br>

                HMSI Unitel dalam rangka mencapai tujuan memiliki bentuk kegiatan antara lain kegiatan pengembangan organisasi, kegiatan pengembangan ilmu pengetahuan dan arah profesi (Seminar, Simposium, Diskusi Ilmiah, Penilitian, dsb) dan pengabdian masyarakat sesuai dengan tujuan HMSI Unitel  maka diharapkan kegiatan yang dilaksanakan baik ditingkat daerah maupun pusat mengacu pada usaha peningkatan kualitas anggota pada bidang riset ilmu pengetahuan dan teknologi yang sesuai dengan profesi Sistem Informasi. Diharapkan kegiatan yang dilaksanakan secara langsung maupun tidak langsung dapat memberikan sumbangan-sumbangan pemikiran dari mahasiswa sebagai insan akademis bagi bangsa dan negara ini.<br>

                </div>
            </div>



          <!--Sec Title-->
            <div id="visimisi" class="sec-title centered" >
              <h2>Visi & Misi</h2>
                 <h3>HMSI 2017-2018</h3>
                <div class="text" style="text-align: justify;">
                <b>Visi</b><br>

                Visi HMSI Telkom University adalah menjadi wadah kesatuan organisasi mahasiswa Sistem Informasi seluruh Indonesia yang bertujuan untuk melahirkan mahasiswa Sistem Informasi yang berwawasan IPTEK dan IMTAQ serta profesional dibidangnya.

                <br>
                <b>Misi</b><br>
                Menjalin komunikasi dan mempererat silaturahmi mahasiswa Sistem Informasi dan membangun jaringan antara anggota dan alumni dalam rangka meningkatan penguasaan IPTEK dan profesionalisme Sistem Informasi.<br>
                Meningkatkan peran HMSI Unitel agar menjadi organisasi kemahasiswaan yang menuju basis keprofesian dengan memantapkan keberadaan organisasi di kalangan anggota, masyarakat, pemerintah dan industri.<br>
                Mengembangkan sikap ilmiah dan sikap keahlian atau arah profesi mahasiswa melalui kegiatan dan tradisi ilmiah dalam bidang IPTEK agar mampu berperan aktif dalam pembangunan nasional.<br>
                Mengembangkan organisasi sebagai wadah koordinasi kegiatan dan forum komunikasi untuk mewujudkan partisipasi mahasiswa dalam pengabdian masyarakat dan pembangunan sesuai dengan ilmu Sistem Informasi.<br>

                </div>
            </div> 

            </section>
 






    <!--Speaker Section-->
    <section class="speaker-section" id="strukturorganisasi" >
    	<div class="auto-container">
        	<!--Sec Title-->
            <div class="sec-title centered">
            	<h2>Struktur Organisasi</h2>
                <h3>HMSI 2017-2018</h3>
                
            </div>
       
 

            <div class="images centered">
                <img src="images/resource/struktur-organisasi.jpg"></img>
            </div>
                            

            </div>
        </div>
    </section>
    <!--End Speaker Section-->


 
    <!--Speaker Section-->
    <section class="speaker-section">
        <div class="auto-container">
            <!--Sec Title-->
            <div class="sec-title centered">
                <h2>INTI HMSI</h2>
                <h3>HMSI 2017-2018</h3>
             </div>
            <div class="four-item-carousel owl-carousel owl-theme">
                
                <!--Team Member Two-->
                <div class="team-member-two">
                    <div class="inner-box">
                        <div class="image">
                            <img src="images/Anggota/INTI/INTI-1.png"/>
                         </div>
                        <div class="lower-info">
                            <h3>PRANDA DWIMAS</h3>
                            
                        </div>
                    </div>
                </div>

                <!--Team Member Two-->
                <div class="team-member-two">
                    <div class="inner-box">
                        <div class="image">
                            <img src="images/Anggota/INTI/INTI-2.png"/>
                         </div>
                        <div class="lower-info">
                            <h3>FIKLI PRADANA</h3>
                            
                        </div>
                    </div>
                </div>

       
                                <!--Team Member Two-->
                <div class="team-member-two">
                    <div class="inner-box">
                        <div class="image">
                            <img src="images/Anggota/INTI/INTI-3.png"/>
                         </div>
                        <div class="lower-info">
                            <h3>ANNISA HAFENTY</h3>
                            
                        </div>
                    </div>
                </div>
                                <!--Team Member Two-->
                <div class="team-member-two">
                    <div class="inner-box">
                        <div class="image">
                            <img src="images/Anggota/INTI/INTI-4.png"/>
                         </div>
                        <div class="lower-info">
                            <h3>NAFILAH NOVEHANI </h3>
                            
                        </div>
                    </div>
                </div>
 
               
 
    </section>
    <!--End Speaker Section-->
 





       <!--Speaker Section-->
    <section class="speaker-section" id='departemenbiro'>
    	<div class="auto-container">
        	<!--Sec Title-->
            <div class="sec-title centered">
            	<h2>Departemen dan Biro</h2>
                <h3>HMSI 2017-2018</h3>
             </div>
            <div class="four-item-carousel owl-carousel owl-theme">

            	<!--Team Member Two-->
                <div class="team-member-two">
                	<div class="inner-box">
                    	<div class="image">
                        	<img src="images/Logo/logo-kaderisasi.png" alt="Departemen Kaderisasi" />
                         </div>
                        <div class="lower-info">
                        	<h3>DEPARTEMEN KADERISASI</h3>
                            
                        </div>
                    </div>
                </div>

            	<!--Team Member Two-->
                <div class="team-member-two">
                	<div class="inner-box">
                    	<div class="image">
                        	<img src="images/Logo/logo-ristek.png" alt="Departemen Ristek" />
                         </div>
                        <div class="lower-info">
                        	<h3>DEPARTEMEN RISET DAN TEKNOLOGI</h3>
                            
                        </div>
                    </div>
                </div>


            	<!--Team Member Two-->
                <div class="team-member-two">
                	<div class="inner-box">
                    	<div class="image">
                        	<img src="images/Logo/logo-kemahasiswaan.png" alt="Departemen Kemahasiswaan" />
                         </div>
                        <div class="lower-info">
                        	<h3>DEPARTEMEN KEMAHASISWAAN</h3>
                            
                        </div>
                    </div>
                </div>


            	<!--Team Member Two-->
                <div class="team-member-two">
                	<div class="inner-box">
                    	<div class="image">
                        	<img src="images/Logo/logo-hrd.png" alt="Departemen HRD" />
                         </div>
                        <div class="lower-info">
                        	<h3>DEPARTEMEN HUMAN RESOURCES DEVELOPMENT</h3>
                            
                        </div>
                    </div>
                </div>


            	<!--Team Member Two-->
                <div class="team-member-two">
                	<div class="inner-box">
                    	<div class="image">
                        	<img src="images/Logo/logo-epr.png" alt="Departemen Enterpreneur" />
                         </div>
                        <div class="lower-info">
                        	<h3>DEPARTEMEN ENTERPRENEUR</h3>
                            
                        </div>
                    </div>
                </div>

     	<!--Team Member Two-->
                <div class="team-member-two">
                	<div class="inner-box">
                    	<div class="image">
                        	<img src="images/Logo/logo-kominfo.png" alt="Departemen Komunkasi dan Informasi" />
                         </div>
                        <div class="lower-info">
                        	<h3>DEPARTEMEN KOMUNIKASI DAN INFORMASI</h3>
                            
                        </div>
                    </div>
                </div>                

            	<!--Team Member Two-->
                <div class="team-member-two">
                	<div class="inner-box">
                    	<div class="image">
                        	<img src="images/Logo/logo-akademik.png" alt="Departemen Akademik" />
                         </div>
                        <div class="lower-info">
                        	<h3>DEPARTEMEN AKADEMIK</h3>
                            
                        </div>
                    </div>
                </div>


        <!--Team Member Two-->
                <div class="team-member-two">
                    <div class="inner-box">
                        <div class="image">
                            <img src="images/Logo/logo-relasi.png" alt="Biro Relasi" />
                         </div>
                        <div class="lower-info">
                            <h3>BIRO RELASI</h3>
                            
                        </div>
                    </div>
                </div>


            	<!--Team Member Two-->
                <div class="team-member-two">
                	<div class="inner-box">
                    	<div class="image">
                        	<img src="images/Logo/logo-dm.png" alt="Biro Dedikasi Masyarakat" />
                         </div>
                        <div class="lower-info">
                        	<h3>BIRO DEDIKASI MASYARAKAT</h3>
                            
                        </div>
                    </div>
                </div>



            </div>
        </div>
    </section>
    <!--End Speaker Section-->
 




    <!--Main Footer-->
    <footer class="main-footer footer-style-two">
        <div class="auto-container">



            <!--Footer Info Section-->
            <div class="footer-info-section">
                <div class="row clearfix">
                    <!--Column-->
                    <div class="column col-md-4 col-sm-6 col-xs-12">
                        <div class="footer-info">
                            <div class="inner">
                                <div class="icon flaticon-location-pin"></div>
                                <div class="text">
                                <b>Gedung C - Fakultas Rekayasa Industri</b><br>
                                Jl. Telekomunikasi Terusan Buah Batu<br>
                                Bandung 40257 Indonesia<br>
                                Telp: 62-22-756 4108<br>
                                Fax: 62-22 7565 930<br>
                                


                                </div>
                            </div>
                        </div>
                    </div>

                    <!--Column-->
                    <div class="column col-md-4 col-sm-6 col-xs-12">
                        <div class="footer-info">
                            <div class="inner">
                                <div  class="icon fa fa-globe"></div>
                                <div class="text">hmsi.telkomuniversity.ac.id</div>
                            </div>
                        </div>
                    </div>

                    <!--Column-->
                    <div class="column col-md-4 col-sm-6 col-xs-12">
                        <div class="footer-info">
                            <div class="inner">
                                <div class="icon flaticon-envelope"></div>
                                <div class="text">ristek_hmsi@gmail.com</div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>

        </div>
        <!--Footer Bottom-->
        <div class="footer-bottom">
            <div class="auto-container">
                <div class="row clearfix">
                    <div class="column col-md-6 col-sm-12 col-xs-12">
                        <div class="copyright">COPYRIGHT &copy; 2017 - Departement Ristek HMSI</div>
                    </div>
                    <div class="column col-md-6 col-sm-12 col-xs-12">
                        <ul class="social-icon-four">
                            <li><a href="#"><span class="fa fa-facebook"></span></a></li>
                            <li><a href="#"><span class="fa fa-twitter"></span></a></li>
                            <li><a href="#"><span class="fa fa-instagram"></span></a></li>
                            <li><a href="#"><span class="fa fa-google-plus"></span></a></li>
                            <li><a href="#"><span class="fa fa-linkedin"></span></a></li>
                            <li><a href="#"><span class="fa fa-pinterest-p"></span></a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!--End Main Footer-->

</div>
<!--End pagewrapper-->

<!--Scroll to top-->
<div class="scroll-to-top scroll-to-target" data-target=".main-header"><span class="icon fa fa-long-arrow-up"></span></div>




<script src="/js/jquery.js"></script>
<script src="/js/bootstrap.min.js"></script>
<script src="/js/revolution.min.js"></script>
<script src="/js/jquery-ui.js"></script>
<script src="/js/jquery.fancybox.pack.js"></script>
<script src="/js/jquery.fancybox-media.js"></script>
<script src="/js/owl.js"></script>
<script src="/js/wow.js"></script>
<script src="/js/appear.js"></script>
<script src="/js/jquery.countdown.js"></script>
<script src="/js/script.js"></script>

<!--Color Switcher Script-->
<script src="js/color-settings.js"></script>
</body>

<!-- Mirrored from t.commonsupport.com/torino/index-2.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 08 Aug 2017 12:39:48 GMT -->
</html>
