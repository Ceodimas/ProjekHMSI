<?php $__env->startSection('title', 'Biro Relasi'); ?>

<?php $__env->startSection('content'); ?>
 
            
   
    
    <!--About Section Two-->
    <section class="about-section-two">
        <div class="auto-container">
            <div class="row clearfix">
                <!--Content Column-->
                <div class="content-column col-md-6 col-sm-12 col-xs-12">
                    <div class="inner">
                        <div class="about-title">
                        <div class="sub-title">Deskripsi</div>
                        <h2>Biro Relasi</h2>
                        </div>
                        
                        <div class="text">
                        Biro Relasi adalah Biro yang bertugas Penghubung HMSI baik internal maupun eksternal HMSI untuk membentuk sebuah relasi dan jaringan yang dapat membantu tumbuh kembangnya HMSI menjadi lebih baik.
                        
                        

                        <h2>Program Kerja</h2>
                    	1. Satu Hati <br>
                        2.  HiVi! (Himpunan Visit)<br>
                        3.  Pra-Sisfotime<br>
                        4.  GradDay!<br>
                        5.  IS Trip<br>



                        </div>

                    </div>
                </div>
                <!--Video Column-->
                <div class="video-column col-md-6 col-sm-12 col-xs-12">
                    <div class="video-box">
                        
                            <img src="images/Logo/logo-relasi.png" alt="Biro Relasi">
                        
                      
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--End About Section Two-->
    <?php $__env->stopSection(); ?>


    <?php $__env->startSection('member'); ?>

    <!--Speaker Section-->
    <section class="speaker-section">
        <div class="auto-container">
            <!--Sec Title-->
            <div class="sec-title centered">
                <h2>Anggota Biro Relasi</h2>
                <h3>HMSI 2017-2018</h3>
             </div>
            <div class="four-item-carousel owl-carousel owl-theme">


             <!--Team Member Two-->
                <div class="team-member-two">
                    <div class="inner-box">
                        <div class="image">
                            <img src="images/Anggota/RELASI/RELASI-7.png" />
                         </div>
                        <div class="lower-info">
                            <h3>PANDU</h3>
                            
                        </div>
                    </div>
                </div>




                <!--Team Member Two-->
                <div class="team-member-two">
                    <div class="inner-box">
                        <div class="image">
                            <img src="images/Anggota/RELASI/RELASI-1.png"/>
                         </div>
                        <div class="lower-info">
                            <h3>INTAN GANTIRA</h3>
                            
                        </div>
                    </div>
                </div>

                <!--Team Member Two-->
                <div class="team-member-two">
                    <div class="inner-box">
                        <div class="image">
                            <img src="images/Anggota/RELASI/RELASI-2.png"   />
                         </div>
                        <div class="lower-info">
                            <h3>DELIA FARIZKI</h3>
                            
                        </div>
                    </div>
                </div>


                <!--Team Member Two-->
                <div class="team-member-two">
                    <div class="inner-box">
                        <div class="image">
                            <img src="images/Anggota/RELASI/RELASI-3.png"   />
                         </div>
                        <div class="lower-info">
                            <h3>IRFAN HAMDANI</h3>
                            
                        </div>
                    </div>
                </div>


                <!--Team Member Two-->
                <div class="team-member-two">
                    <div class="inner-box">
                        <div class="image">
                            <img src="images/Anggota/RELASI/RELASI-4.png"  />
                         </div>
                        <div class="lower-info">
                            <h3>RIFQI MAHFUZH</h3>
                            
                        </div>
                    </div>
                </div>


                <!--Team Member Two-->
                <div class="team-member-two">
                    <div class="inner-box">
                        <div class="image">
                            <img src="images/Anggota/RELASI/RELASI-5.png"   />
                         </div>
                        <div class="lower-info">
                            <h3>ANGELA MALAU</h3>
                            
                        </div>
                    </div>
                </div>

        <!--Team Member Two-->
                <div class="team-member-two">
                    <div class="inner-box">
                        <div class="image">
                            <img src="images/Anggota/RELASI/RELASI-6.png"  />
                         </div>
                        <div class="lower-info">
                            <h3>DICKY ADITAMA</h3>
                            
                        </div>
                    </div>
                </div>                

    
                <div class="team-member-two">
                    <div class="inner-box">
                        <div class="image">
                            <img src="images/Anggota/RELASI/RELASI-8.png"  />
                         </div>
                        <div class="lower-info">
                            <h3>DIBYO</h3>
                            
                        </div>
                    </div>
                </div>           


                <div class="team-member-two">
                    <div class="inner-box">
                        <div class="image">
                            <img src="images/Anggota/RELASI/RELASI-9.png"  />
                         </div>
                        <div class="lower-info">
                            <h3>IRHA SALWA S</h3>
                            
                        </div>
                    </div>
                </div>           
 


               
 
    </section>
    <!--End Speaker Section-->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.hmsi-app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>