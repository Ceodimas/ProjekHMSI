<?php $__env->startSection('title', 'Biro Dedikasi Masyarakat'); ?>

<?php $__env->startSection('content'); ?>
 
            
   
    
    <!--About Section Two-->
    <section class="about-section-two">
        <div class="auto-container">
            <div class="row clearfix">
                <!--Content Column-->
                <div class="content-column col-md-6 col-sm-12 col-xs-12">
                    <div class="inner">
                        <div class="about-title">
                        <div class="sub-title">Deskripsi</div>
                        <h2>Biro Dedikasi Masyarakat</h2>
                        </div>
                        
                        <div class="text">
                        Biro Dedikasi Masyarakat adalah Biro yang bertugas melakukan analisis kebutuhan masyarakat sekitar Telkom University dan masyarakat Sistem Informasi dibidang sosial dan merealisasikan dalam program kerja pengabdian masyarakat
                        
                        

                        <h2>Program Kerja</h2>
                    	1.	Monthly Care<br>
						2.	System, Management Application (SMA)<br>
						3.	Smiling Information System (SIS)<br>


                        </div>

                    </div>
                </div>
                <!--Video Column-->
                <div class="video-column col-md-6 col-sm-12 col-xs-12">
                    <div class="video-box">
                        
                            <img src="images/Logo/logo-dm.png" alt="Biro Dedikasi Masyarakat">
                        
                      
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--End About Section Two-->
    <?php $__env->stopSection(); ?>


    <?php $__env->startSection('member'); ?>

    <!--Speaker Section-->
    <section class="speaker-section">
        <div class="auto-container">
            <!--Sec Title-->
            <div class="sec-title centered">
                <h2>Anggota Biro Dedikasi Masyarakat</h2>
                <h3>HMSI 2017-2018</h3>
             </div>
            <div class="four-item-carousel owl-carousel owl-theme">

                <!--Team Member Two-->
                <div class="team-member-two">
                    <div class="inner-box">
                        <div class="image">
                            <img src="images/Anggota/DM/DM-1.png"/>
                         </div>
                        <div class="lower-info">
                            <h3>HYLDA RIZQA A</h3>
                            
                        </div>
                    </div>
                </div>

                <!--Team Member Two-->
                <div class="team-member-two">
                    <div class="inner-box">
                        <div class="image">
                            <img src="images/Anggota/DM/DM-2.png"   />
                         </div>
                        <div class="lower-info">
                            <h3>RIZALDI HAQIKI</h3>
                            
                        </div>
                    </div>
                </div>


                <!--Team Member Two-->
                <div class="team-member-two">
                    <div class="inner-box">
                        <div class="image">
                            <img src="images/Anggota/DM/DM-3.png"   />
                         </div>
                        <div class="lower-info">
                            <h3>M. RIDWAN</h3>
                            
                        </div>
                    </div>
                </div>


                <!--Team Member Two-->
                <div class="team-member-two">
                    <div class="inner-box">
                        <div class="image">
                            <img src="images/Anggota/DM/DM-4.png"  />
                         </div>
                        <div class="lower-info">
                            <h3>ANDHY BASKORO</h3>
                            
                        </div>
                    </div>
                </div>


                <!--Team Member Two-->
                <div class="team-member-two">
                    <div class="inner-box">
                        <div class="image">
                            <img src="images/Anggota/DM/DM-5.png"   />
                         </div>
                        <div class="lower-info">
                            <h3>SITI HARTINA</h3>
                            
                        </div>
                    </div>
                </div>

        <!--Team Member Two-->
                <div class="team-member-two">
                    <div class="inner-box">
                        <div class="image">
                            <img src="images/Anggota/DM/DM-6.png"  />
                         </div>
                        <div class="lower-info">
                            <h3>ADINDA</h3>
                            
                        </div>
                    </div>
                </div>                

                <!--Team Member Two-->
                <div class="team-member-two">
                    <div class="inner-box">
                        <div class="image">
                            <img src="images/Anggota/DM/DM-7.png" />
                         </div>
                        <div class="lower-info">
                            <h3>ACHRIZAL KHOLID</h3>
                            
                        </div>
                    </div>
                </div>

               
 
    </section>
    <!--End Speaker Section-->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.hmsi-app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>