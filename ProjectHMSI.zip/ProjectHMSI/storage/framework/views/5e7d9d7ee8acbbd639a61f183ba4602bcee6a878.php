<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Todo Lists</title>
  <link href="<?php echo e(asset('/css/bootstrap.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('/css/font-awesome.css')); ?>" rel="stylesheet">


</head>
<body>
  <div class="container">
    <div class='row'>
      <?php $__env->startSection('body'); ?>
        <?php echo $__env->yieldSection(); ?>





    </div>
  </div>
  <script src="/js/bootstrap.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
</body>
</html>
