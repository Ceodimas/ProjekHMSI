<!DOCTYPE html>
<html>

<!-- Mirrored from t.commonsupport.com/torino/index-2.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 08 Aug 2017 12:39:07 GMT -->
<head>
<meta charset="utf-8">
<title>HMSI | <?php echo $__env->yieldContent('title'); ?></title>
<!-- Stylesheets -->




<link href="<?php echo e(asset('/css/bootstrap.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('/css/revolution-slider.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('/css/jquery-ui.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('/css/style.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('/css/responsive.css')); ?>" rel="stylesheet">



<!--Color Switcher Mockup-->




<!--Color Themes-->
<link href="css/color-themes/blue-theme.css" rel="stylesheet">


<!--Favicon-->
<link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon">
<link rel="icon" href="images/favicon.ico" type="image/x-icon">
<!-- Responsive -->
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
<!--[if lt IE 9]><script src="https://cdnjs.cloudflare.com/ajax/libs/html5shiv/3.7.3/html5shiv.js"></script><![endif]-->
<!--[if lt IE 9]><script src="js/respond.js"></script><![endif]-->
</head>

<body>

<div class="page-wrapper">

    <!-- Preloader -->
    <div class="preloader"></div>

    <!-- Main Header -->
    <header class="main-header header-style-two">
    	<!-- Header Top-->
    	<div class="header-top style-two">
        	<div class="auto-container">
            	<div class="clearfix">

                    <!--Top Left-->
                    <div class="top-left top-links">
                    	<ul class="clearfix">
                        	<li><a href="#"><span class="icon fa fa-globe"></span> hmsi.telkomuniversity.ac.id </a></li>
                            <li><a href="#"><span class="icon fa fa-envelope-o"></span> ristek_hmsi@gmail.com</a></li>
                        </ul>
                    </div>

                    <!--Top Right-->
                    <div class="top-right">
                    	<div class="social-icon">
                            <a href="#"><span class="fa fa-facebook"></span></a>
                            <a href="#"><span class="fa fa-twitter"></span></a>
                            <a href="#"><span class="fa fa-google-plus"></span></a>
                            <a href="#"><span class="fa fa-youtube"></span></a>
                            <a href="#"><span class="fa fa-instagram"></span></a>
                        </div>
                    </div>

                </div>

            </div>
        </div>
        <!-- Header Top One End -->

        <!-- Header Lower -->
        <div class="header-lower">
            <div class="main-box">
                <div class="auto-container">
                    <div class="outer-container clearfix">
                        <!--Logo Box-->
                        <div class="logo-box">
                            <div class="logo"><a href="index-2.html"><img src="images/logo-2.png" alt=""></a></div>
                        </div>

                        <!--Nav Outer-->
                        <div class="nav-outer clearfix">
                            <!-- Main Menu -->
                            <nav class="main-menu">
                                <div class="navbar-header">
                                    <!-- Toggle Button -->
                                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                    </button>
                                </div>

                                <div class="navbar-collapse collapse clearfix">
                                    <ul class="navigation clearfix">


                                        <li><a href="/todo">BERANDA</a></li>
                                        <li class="dropdown"><a href="/hmsi">HMSI</a>
                                            <ul>
                                                <li><a class="scroll-to-target" href="/hmsi#sejarah">Sejarah</a></li>
                                                <li><a class="scroll-to-target" href="/hmsi#visimisi">Visi dan Misi</a></li>
                                                <li><a class="scroll-to-target" href="/hmsi#strukturorganisasi">Struktur Organisasi</a></li>
                                                <li class="dropdown"><a scroll-to-target" href="/hmsi#departemenbiro">Departement dan Biro</a>
                                                    <ul>
                                                        <li><a href="/hmsi/kaderisasi">Kaderisasi</a></li>
                                                        <li><a href="/hmsi/ristek">Riset dan Teknologi</a></li>
                                                        <li><a href="/hmsi/kemahasiswaan">Kemahasiswaan</a></li>
                                                        <li><a href="/hmsi/hrd">Human Resources Development</a></li>
                                                        <li><a href="/hmsi/erp">Enterpreneur</a></li>
                                                        <li><a href="/hmsi/kominfo">Komunikasi dan Informasi</a></li>
                                                        <li><a href="/hmsi/akademik">Akademik</a></li>
                                                        <li><a href="/hmsi/dm">Dedikasi Masyarakat</a></li>
                                                        <li><a href="/hmsi/relasi">Relasi</a></li>
                                                    </ul>
                                                </li>
                                            </ul>
                                        </li>


                                        <li class=" dropdown"><a href="/laboratorium/beranda">LABORATORIUM</a>
                                            <ul>
                                                <li><a href="/laboratorium/sisjar">SISJAR</a></li>
                                                <li><a href="/laboratorium/prodase">PRODASE</a></li>
                                                <li><a href="/laboratorium/erp">ERP</a></li>
                                                <li><a href="/laboratorium/bpad">BPAD</a></li>
                                            </ul>
                                        </li>

                                        <li class=" dropdown"><a href="/keprofesian/beranda">KEPROFESIAN</a>
                                            <ul>
                                                <li><a href="/keprofesian/elc">ERP Laboratory Club</a></li>
                                                <li><a href="/keprofesian/blc">BPAD Laboratory Club</a></li>
                                            </ul>
                                        </li>


                                        <li class=" dropdown"><a href="/event/beranda">EVENT</a>
                                            <ul>
                                                <li><a href="/event/agenda">AGENDA</a></li>
                                                <li><a href="/event/galery">GALERI</a></li>
                                            </ul>
                                        </li>

                                        <li><a href="/tokohmsi">TOKO HMSI</a></li>


                                        <li><a href="/hubungikami">HUBUNGI KAMI</a></li>
                                     </ul>
                                </div>
                            </nav><!-- Main Menu End-->

                            <!--Button Outer-->
                            <div class="btn-outer">

                                <div class="dropdown">
                                    <button class="search-box-btn dropdown-toggle" type="button" id="dropdownMenu3" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><span class="fa fa-search"></span></button>
                                    <ul class="dropdown-menu pull-right search-panel" aria-labelledby="dropdownMenu3">
                                        <li class="panel-outer">
                                            <div class="form-container">
                                                <form method="post" action="http://t.commonsupport.com/torino/blog.html">
                                                    <div class="form-group">
                                                        <input type="search" name="field-name" value="" placeholder="Search Here" required="">
                                                        <button type="submit" class="search-btn"><span class="fa fa-search"></span></button>
                                                    </div>
                                                </form>
                                            </div>
                                        </li>
                                    </ul>
                                </div>

                            	
                            </div>

                        </div><!--Nav Outer End-->

                    </div>
                </div>
            </div>
        </div>

        <!--Sticky Header-->
        <div class="sticky-header">
            <div class="auto-container clearfix">
                <!--Logo-->
                <div class="logo pull-left">
                    <a href="index-2.html" class="img-responsive"><img src="images/logo-small.png" alt="" title=""></a>
                </div>

                <!--Right Col-->
                <div class="right-col pull-right">
                    <!-- Main Menu -->
                    <nav class="main-menu">
                        <div class="navbar-header">
                            <!-- Toggle Button -->
                            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            </button>
                        </div>

                        <div class="navbar-collapse collapse clearfix">
                            <ul class="navigation clearfix">
                                        <li><a href="/todo">BERANDA</a></li>
                                        <li class="dropdown"><a href="/hmsi">HMSI</a>
                                            <ul>
                                                <li><a class="scroll-to-target" href="/hmsi#sejarah">Sejarah</a></li>
                                                <li><a class="scroll-to-target" href="/hmsi#visimisi">Visi dan Misi</a></li>
                                                <li><a class="scroll-to-target" href="/hmsi#strukturorganisasi">Struktur Organisasi</a></li>
                                                <li class="dropdown"><a scroll-to-target" href="/hmsi#departemenbiro">Departement dan Biro</a>
                                                    <ul>
                                                        <li><a href="/hmsi/kaderisasi">Kaderisasi</a></li>
                                                        <li><a href="/hmsi/ristek">Riset dan Teknologi</a></li>
                                                        <li><a href="/hmsi/kemahasiswaan">Kemahasiswaan</a></li>
                                                        <li><a href="/hmsi/hrd">Human Resources Development</a></li>
                                                        <li><a href="/hmsi/epr">Enterpreneur</a></li>
                                                        <li><a href="/hmsi/kominfo">Komunikasi dan Informasi</a></li>
                                                        <li><a href="/hmsi/akademik">Akademik</a></li>
                                                        <li><a href="/hmsi/dm">Dedikasi Masyarakat</a></li>
                                                        <li><a href="/hmsi/relasi">Relasi</a></li>
                                                    </ul>
                                                </li>
                                            </ul>
                                        </li>


                                        <li class=" dropdown"><a href="/laboratorium/beranda">LABORATORIUM</a>
                                            <ul>
                                                <li><a href="/laboratorium/sisjar">SISJAR</a></li>
                                                <li><a href="/laboratorium/prodase">PRODASE</a></li>
                                                <li><a href="/laboratorium/erp">ERP</a></li>
                                                <li><a href="/laboratorium/bpad">BPAD</a></li>
                                            </ul>
                                        </li>

                                        <li class=" dropdown"><a href="/keprofesian/beranda">KEPROFESIAN</a>
                                            <ul>
                                                <li><a href="/keprofesian/elc">ERP Laboratory Club</a></li>
                                                <li><a href="/keprofesian/blc">BPAD Laboratory Club</a></li>
                                            </ul>
                                        </li>


                                        <li class=" dropdown"><a href="/event/beranda">EVENT</a>
                                            <ul>
                                                <li><a href="/event/agenda">AGENDA</a></li>
                                                <li><a href="/event/galery">GALERI</a></li>
                                            </ul>
                                        </li>

                                        <li><a href="/tokohmsi">TOKO HMSI</a></li>


                                        <li><a href="/hubungikami">HUBUNGI KAMI</a></li>
                                     </ul>
 
                        </div>
                    </nav><!-- Main Menu End-->
                </div>

            </div>
        </div>
        <!--End Sticky Header-->

    </header>
    <!--End Main Header -->

    <!--Main Slider-->
    <section class="main-slider" data-start-height="800" data-slide-overlay="yes">

        <div class="tp-banner-container">
            <div class="tp-banner">
                <ul>

                    <li data-transition="fade" data-slotamount="1" data-masterspeed="1000" data-thumb="images/main-slider/1.jpg"  data-saveperformance="off"  data-title="Awesome Title Here">
                    <img src="images/main-slider/1.jpg"  alt=""  data-bgposition="center top" data-bgfit="cover" data-bgrepeat="no-repeat">

                    <div class="tp-caption sft sfb tp-resizeme"
                    data-x="left" data-hoffset="15"
                    data-y="center" data-voffset="-70"
                    data-speed="1500"
                    data-start="0"
                    data-easing="easeOutExpo"
                    data-splitin="none"
                    data-splitout="none"
                    data-elementdelay="0.01"
                    data-endelementdelay="0.3"
                    data-endspeed="1200"
                    data-endeasing="Power4.easeIn"><div class="sub-title alternate">PORTAL HMSI</div></div>

                    <div class="tp-caption sft sfb tp-resizeme"
                    data-x="left" data-hoffset="15"
                    data-y="center" data-voffset="30"
                    data-speed="1500"
                    data-start="500"
                    data-easing="easeOutExpo"
                    data-splitin="none"
                    data-splitout="none"
                    data-elementdelay="0.01"
                    data-endelementdelay="0.3"
                    data-endspeed="1200"
                    data-endeasing="Power4.easeIn"><h2>Portal Informasi seputar HMSI<br> Telkom University </h2></div>


                    </li>


                </ul>
            </div>
        </div>
    </section>
    <!--End Main Slider-->

    <!--About Section Two-->
    <section class="about-section-two">
    	<div class="auto-container">
        	<div class="row clearfix">
            	<!--Content Column-->
                <div class="content-column col-md-6 col-sm-12 col-xs-12">
                	<div class="inner">
                    	<div class="about-title">
                        	<div class="sub-title">Sambutan Ketua HMSI</div>
                            <h2>Selamat Datang</h2>
                        </div>

                        <div class="text">
                          Selamat datang di Portal HMSI, disini kami sajikan berbagai informasi mengenai apa saja yang ada di dalam jurusan kita, Sistem Informasi.
                          Rubrik seputar event, informasi laboratorium, dan organisasi bisa kalian akses disini.

                        </div>
                        <a href="about-us.html" class="theme-btn btn-style-one">learn more</a>
                    </div>
                </div>
                <!--Video Column-->
                <div class="video-column col-md-6 col-sm-12 col-xs-12">
                	<div class="video-box">
                        <figure class="image">
                            <img src="images/resource/video-img.jpg" alt="">
                        </figure>
                        <a href="https://www.youtube.com/watch?v=kxPCFljwJws" class="lightbox-image overlay-box"><span class="flaticon-arrow"></span></a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--End About Section Two-->

    <!--Subscribe section-->



    
    <!--End Subscribe section-->

    <!--Speaker Section-->
    <section class="speaker-section">
    	<div class="auto-container">
        	<!--Sec Title-->
            <div class="sec-title centered">
            	<h2>Struktur Organisasi</h2>
                <h3>HMSI 2017-2018</h3>
                <div class="text">Nunc commodo tellus diam, sed molestie quam fermentum varius. Etiam finibus lorem vel interdum volutpat. Suspendisse lorem vel interdum volutpat. Suspendisse  </div>
            </div>
            <div class="four-item-carousel owl-carousel owl-theme">

            	<!--Team Member Two-->
                <div class="team-member-two">
                	<div class="inner-box">
                    	<div class="image">
                        	<img src="images/resource/team-7.jpg" alt="" />
                            <div class="social-box">
                            	<ul class="social-icon-three">
                                	<li><a href="#"><span class="fa fa-facebook"></span></a></li>
                                    <li><a href="#"><span class="fa fa-twitter"></span></a></li>
                                    <li><a href="#"><span class="fa fa-linkedin"></span></a></li>
                                    <li><a href="#"><span class="fa fa-instagram"></span></a></li>
                                    <li><a href="#"><span class="fa fa-google-plus"></span></a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="lower-info">
                        	<h3>PRANDA DWIMAS</h3>
                            <div class="designation">KETUA HIMPUNAN</div>
                        </div>
                    </div>
                </div>

                <!--Team Member Two-->
                <div class="team-member-two">
                	<div class="inner-box">
                    	<div class="image">
                        	<img src="images/resource/team-8.jpg" alt="" />
                            <div class="social-box">
                            	<ul class="social-icon-three">
                                	<li><a href="#"><span class="fa fa-facebook"></span></a></li>
                                    <li><a href="#"><span class="fa fa-twitter"></span></a></li>
                                    <li><a href="#"><span class="fa fa-linkedin"></span></a></li>
                                    <li><a href="#"><span class="fa fa-instagram"></span></a></li>
                                    <li><a href="#"><span class="fa fa-google-plus"></span></a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="lower-info">
                        	<h3>CHELSIE</h3>
                            <div class="designation">GM, The boxtrap</div>
                        </div>
                    </div>
                </div>

                <!--Team Member Two-->
                <div class="team-member-two">
                	<div class="inner-box">
                    	<div class="image">
                        	<img src="images/resource/team-9.jpg" alt="" />
                            <div class="social-box">
                            	<ul class="social-icon-three">
                                	<li><a href="#"><span class="fa fa-facebook"></span></a></li>
                                    <li><a href="#"><span class="fa fa-twitter"></span></a></li>
                                    <li><a href="#"><span class="fa fa-linkedin"></span></a></li>
                                    <li><a href="#"><span class="fa fa-instagram"></span></a></li>
                                    <li><a href="#"><span class="fa fa-google-plus"></span></a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="lower-info">
                        	<h3>ROBIN A. GUZMAN</h3>
                            <div class="designation">CEO, Slack</div>
                        </div>
                    </div>
                </div>

                <!--Team Member Two-->
                <div class="team-member-two">
                	<div class="inner-box">
                    	<div class="image">
                        	<img src="images/resource/team-10.jpg" alt="" />
                            <div class="social-box">
                            	<ul class="social-icon-three">
                                	<li><a href="#"><span class="fa fa-facebook"></span></a></li>
                                    <li><a href="#"><span class="fa fa-twitter"></span></a></li>
                                    <li><a href="#"><span class="fa fa-linkedin"></span></a></li>
                                    <li><a href="#"><span class="fa fa-instagram"></span></a></li>
                                    <li><a href="#"><span class="fa fa-google-plus"></span></a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="lower-info">
                        	<h3>CODY L. BALL</h3>
                            <div class="designation">Pixar Animation</div>
                        </div>
                    </div>
                </div>

                <!--Team Member Two-->
                <div class="team-member-two">
                	<div class="inner-box">
                    	<div class="image">
                        	<img src="images/resource/team-7.jpg" alt="" />
                            <div class="social-box">
                            	<ul class="social-icon-three">
                                	<li><a href="#"><span class="fa fa-facebook"></span></a></li>
                                    <li><a href="#"><span class="fa fa-twitter"></span></a></li>
                                    <li><a href="#"><span class="fa fa-linkedin"></span></a></li>
                                    <li><a href="#"><span class="fa fa-instagram"></span></a></li>
                                    <li><a href="#"><span class="fa fa-google-plus"></span></a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="lower-info">
                        	<h3>Jamie Wein</h3>
                            <div class="designation">CEO, Hatem Co</div>
                        </div>
                    </div>
                </div>

                <!--Team Member Two-->
                <div class="team-member-two">
                	<div class="inner-box">
                    	<div class="image">
                        	<img src="images/resource/team-8.jpg" alt="" />
                            <div class="social-box">
                            	<ul class="social-icon-three">
                                	<li><a href="#"><span class="fa fa-facebook"></span></a></li>
                                    <li><a href="#"><span class="fa fa-twitter"></span></a></li>
                                    <li><a href="#"><span class="fa fa-linkedin"></span></a></li>
                                    <li><a href="#"><span class="fa fa-instagram"></span></a></li>
                                    <li><a href="#"><span class="fa fa-google-plus"></span></a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="lower-info">
                        	<h3>CHELSIE</h3>
                            <div class="designation">GM, The boxtrap</div>
                        </div>
                    </div>
                </div>

                <!--Team Member Two-->
                <div class="team-member-two">
                	<div class="inner-box">
                    	<div class="image">
                        	<img src="images/resource/team-9.jpg" alt="" />
                            <div class="social-box">
                            	<ul class="social-icon-three">
                                	<li><a href="#"><span class="fa fa-facebook"></span></a></li>
                                    <li><a href="#"><span class="fa fa-twitter"></span></a></li>
                                    <li><a href="#"><span class="fa fa-linkedin"></span></a></li>
                                    <li><a href="#"><span class="fa fa-instagram"></span></a></li>
                                    <li><a href="#"><span class="fa fa-google-plus"></span></a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="lower-info">
                        	<h3>ROBIN A. GUZMAN</h3>
                            <div class="designation">CEO, Slack</div>
                        </div>
                    </div>
                </div>

                <!--Team Member Two-->
                <div class="team-member-two">
                	<div class="inner-box">
                    	<div class="image">
                        	<img src="images/resource/team-10.jpg" alt="" />
                            <div class="social-box">
                            	<ul class="social-icon-three">
                                	<li><a href="#"><span class="fa fa-facebook"></span></a></li>
                                    <li><a href="#"><span class="fa fa-twitter"></span></a></li>
                                    <li><a href="#"><span class="fa fa-linkedin"></span></a></li>
                                    <li><a href="#"><span class="fa fa-instagram"></span></a></li>
                                    <li><a href="#"><span class="fa fa-google-plus"></span></a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="lower-info">
                        	<h3>CODY L. BALL</h3>
                            <div class="designation">Pixar Animation</div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </section>
    <!--End Speaker Section-->

    <!--FullWidth Section One-->
    <section class="fullwidth-section">
    	<div class="section-outer clearfix">

            <!--Form Column-->
        	<div class="form-column">
            	<div class="inner">
					<h2>Register Free Form</h2>
                    <div class="text">100% Secure gateway</div>

                    <!--Signup Form-->
                    <div class="signup-form">
                        <form method="post" action="http://t.commonsupport.com/torino/contact.html">

                            <div class="form-group">
                                <input type="text" name="username" value="" placeholder="Your Name" required>
                            </div>

                            <div class="form-group">
                            	<input type="email" name="email" value="" placeholder="Email address" required>
                            </div>

                            <div class="form-group">
                                <input type="text" name="number" value="" placeholder="Phone Number" required>
                            </div>

                            <div class="form-group">
                                <select class="custom-select-box">
                                    <option>Subject</option>
                                    <option>Subject One</option>
                                    <option>Subject Two</option>
                                </select>
                            </div>

                            <div class="form-group">
                                <button type="submit" class="theme-btn btn-style-one">Register Now</button>
                            </div>

                        </form>
                    </div>

                </div>
            </div>

        	<!--Image Column-->
        	<div class="image-column" style="background-image:url(images/resource/fullwidth-1.jpg);">
            	<div class="hidden-image">
                	<img src="images/resource/fullwidth-1.jpg" alt="" />
                </div>
            </div>
		</div>
    </section>
    <!--End FullWidth Section One-->

    <!--Travel Section-->
    <section class="travel-section">
    	<div class="auto-container">
        	<!--Sec Title-->
            <div class="sec-title centered">
            	<h2>Travel Information</h2>
                <h3>Journey</h3>
                <div class="text">Nunc commodo tellus diam, sed molestie quam fermentum varius. Etiam finibus lorem vel interdum volutpat. Suspendisse lorem vel interdum volutpat. Suspendisse  </div>
            </div>
            <div class="row clearfix">

                <!--Travel Block-->
                <div class="travel-block col-md-4 col-sm-6 col-xs-12">
                	<div class="inner-box">
                    	<div class="image">
                        	<a href="blog-single.html"><img src="images/resource/travel-1.jpg" alt="" /></a>
                        </div>
                        <div class="lower-box">
                        	<div class="location">Liverpool, London</div>
                            <h3><a href="blog-single.html">LOCATION of the event</a></h3>
                            <div class="text">We build up the best education nvironment for themselves at most</div>
                            <a href="blog-single.html" class="theme-btn btn-style-one">Read More</a>
                        </div>
                    </div>
                </div>

                <!--Travel Block-->
                <div class="travel-block col-md-4 col-sm-6 col-xs-12">
                	<div class="inner-box">
                    	<div class="image">
                        	<a href="blog-single.html"><img src="images/resource/travel-2.jpg" alt="" /></a>
                        </div>
                        <div class="lower-box">
                        	<div class="location">Modern Conference Center</div>
                            <h3><a href="blog-single.html">VENUE of the event</a></h3>
                            <div class="text">We build up the best education nvironment for themselves at most</div>
                            <a href="blog-single.html" class="theme-btn btn-style-one">Read More</a>
                        </div>
                    </div>
                </div>

                <!--Travel Block-->
                <div class="travel-block col-md-4 col-sm-6 col-xs-12">
                	<div class="inner-box">
                    	<div class="image">
                        	<a href="blog-single.html"><img src="images/resource/travel-3.jpg" alt="" /></a>
                        </div>
                        <div class="lower-box">
                        	<div class="location">Top Hotels in Liverpool</div>
                            <h3><a href="blog-single.html">Hotel & Restaurant</a></h3>
                            <div class="text">We build up the best education nvironment for themselves at most</div>
                            <a href="blog-single.html" class="theme-btn btn-style-one">Read More</a>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </section>
    <!--End Travel Section-->


    <!--Schedule Section-->
    <section class="schedule-section" style="background-image:url(images/background/3.jpg);">
    	<div class="auto-container">
        	<!--Sec Title-->
            <div class="sec-title light centered">
            	<h2>Event Shedule</h2>
                <h3>Event</h3>
                <div class="text">Nunc commodo tellus diam, sed molestie quam fermentum varius. Etiam finibus lorem vel interdum volutpat. Suspendisse lorem vel interdum volutpat. Suspendisse  </div>
            </div>

            <div class="schedule-carousel-outer">
            	<!--Days Outer-->
                <div class="days-outer">
                	<ul class="days-carousel owl-theme owl-carousel">
                    	<li class="day"><div class="btn-inner"><div class="icon"><span class="flaticon-clock-1"></span></div>Day 1</div></li>
                        <li class="day"><div class="btn-inner"><div class="icon"><span class="flaticon-clock-1"></span></div>Day 2</div></li>
                        <li class="day"><div class="btn-inner"><div class="icon"><span class="flaticon-clock-1"></span></div>Day 3</div></li>
                        <li class="day"><div class="btn-inner"><div class="icon"><span class="flaticon-clock-1"></span></div>Day 4</div></li>
                        <li class="day"><div class="btn-inner"><div class="icon"><span class="flaticon-clock-1"></span></div>Day 5</div></li>
                    </ul>
                </div>

                <!--Speakers Carousel-->
                <div class="speakers-carousel owl-theme owl-carousel">
                    <div class="slide-item">
                    	<div class="inner">
                        	<div class="speakers clearfix">
                            	<div class="speaker">
                                	<div class="image img-circle"><figure class="speaker-image img-circle"><img class="img-circle" src="images/resource/speaker-thumb-1.jpg" alt=""><a href="#" class="over-link"><span class="flaticon-plus-symbol"></span></a></figure></div>
                                    <div class="lower">
                                    	<div class="time">10am - 12pm</div>
                                        <div class="speaker-title">DAVID JHONSHON</div>
                                        <div class="designation">UX/ UI Designer</div>
                                    </div>
                                </div>
                                <div class="speaker">
                                	<div class="image img-circle"><figure class="speaker-image img-circle"><img class="img-circle" src="images/resource/speaker-thumb-2.jpg" alt=""><a href="#" class="over-link"><span class="flaticon-plus-symbol"></span></a></figure></div>
                                    <div class="lower">
                                    	<div class="time">09am - 12pm</div>
                                        <div class="speaker-title">WILLIAM JOHN</div>
                                        <div class="designation">Producer, CSI:Cyber</div>
                                    </div>
                                </div>
                                <div class="speaker">
                                	<div class="image img-circle"><figure class="speaker-image img-circle"><img class="img-circle" src="images/resource/speaker-thumb-3.jpg" alt=""><a href="#" class="over-link"><span class="flaticon-plus-symbol"></span></a></figure></div>
                                    <div class="lower">
                                    	<div class="time">09am - 12pm</div>
                                        <div class="speaker-title">CHELSIE</div>
                                        <div class="designation">CEO, Hatem Co.</div>
                                    </div>
                                </div>
                                <div class="speaker">
                                	<div class="image img-circle"><figure class="speaker-image img-circle"><img class="img-circle" src="images/resource/speaker-thumb-4.jpg" alt=""><a href="#" class="over-link"><span class="flaticon-plus-symbol"></span></a></figure></div>
                                    <div class="lower">
                                    	<div class="time">11am - 01pm</div>
                                        <div class="speaker-title">JEFF SEVERIN</div>
                                        <div class="designation">GM, The boxtrap</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="slide-item">
                    	<div class="inner">
                        	<div class="speakers clearfix">
                            	<div class="speaker">
                                	<div class="image img-circle"><figure class="speaker-image img-circle"><img class="img-circle" src="images/resource/speaker-thumb-1.jpg" alt=""><a href="#" class="over-link"><span class="flaticon-plus-symbol"></span></a></figure></div>
                                    <div class="lower">
                                    	<div class="time">10am - 12pm</div>
                                        <div class="speaker-title">DAVID JHONSHON</div>
                                        <div class="designation">UX/ UI Designer</div>
                                    </div>
                                </div>
                                <div class="speaker">
                                	<div class="image img-circle"><figure class="speaker-image img-circle"><img class="img-circle" src="images/resource/speaker-thumb-2.jpg" alt=""><a href="#" class="over-link"><span class="flaticon-plus-symbol"></span></a></figure></div>
                                    <div class="lower">
                                    	<div class="time">09am - 12pm</div>
                                        <div class="speaker-title">WILLIAM JOHN</div>
                                        <div class="designation">Producer, CSI:Cyber</div>
                                    </div>
                                </div>
                                <div class="speaker">
                                	<div class="image img-circle"><figure class="speaker-image img-circle"><img class="img-circle" src="images/resource/speaker-thumb-3.jpg" alt=""><a href="#" class="over-link"><span class="flaticon-plus-symbol"></span></a></figure></div>
                                    <div class="lower">
                                    	<div class="time">09am - 12pm</div>
                                        <div class="speaker-title">CHELSIE</div>
                                        <div class="designation">CEO, Hatem Co.</div>
                                    </div>
                                </div>
                                <div class="speaker">
                                	<div class="image img-circle"><figure class="speaker-image img-circle"><img class="img-circle" src="images/resource/speaker-thumb-4.jpg" alt=""><a href="#" class="over-link"><span class="flaticon-plus-symbol"></span></a></figure></div>
                                    <div class="lower">
                                    	<div class="time">11am - 01pm</div>
                                        <div class="speaker-title">JEFF SEVERIN</div>
                                        <div class="designation">GM, The boxtrap</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="slide-item">
                    	<div class="inner">
                        	<div class="speakers clearfix">
                            	<div class="speaker">
                                	<div class="image img-circle"><figure class="speaker-image img-circle"><img class="img-circle" src="images/resource/speaker-thumb-1.jpg" alt=""><a href="#" class="over-link"><span class="flaticon-plus-symbol"></span></a></figure></div>
                                    <div class="lower">
                                    	<div class="time">10am - 12pm</div>
                                        <div class="speaker-title">DAVID JHONSHON</div>
                                        <div class="designation">UX/ UI Designer</div>
                                    </div>
                                </div>
                                <div class="speaker">
                                	<div class="image img-circle"><figure class="speaker-image img-circle"><img class="img-circle" src="images/resource/speaker-thumb-2.jpg" alt=""><a href="#" class="over-link"><span class="flaticon-plus-symbol"></span></a></figure></div>
                                    <div class="lower">
                                    	<div class="time">09am - 12pm</div>
                                        <div class="speaker-title">WILLIAM JOHN</div>
                                        <div class="designation">Producer, CSI:Cyber</div>
                                    </div>
                                </div>
                                <div class="speaker">
                                	<div class="image img-circle"><figure class="speaker-image img-circle"><img class="img-circle" src="images/resource/speaker-thumb-3.jpg" alt=""><a href="#" class="over-link"><span class="flaticon-plus-symbol"></span></a></figure></div>
                                    <div class="lower">
                                    	<div class="time">09am - 12pm</div>
                                        <div class="speaker-title">CHELSIE</div>
                                        <div class="designation">CEO, Hatem Co.</div>
                                    </div>
                                </div>
                                <div class="speaker">
                                	<div class="image img-circle"><figure class="speaker-image img-circle"><img class="img-circle" src="images/resource/speaker-thumb-4.jpg" alt=""><a href="#" class="over-link"><span class="flaticon-plus-symbol"></span></a></figure></div>
                                    <div class="lower">
                                    	<div class="time">11am - 01pm</div>
                                        <div class="speaker-title">JEFF SEVERIN</div>
                                        <div class="designation">GM, The boxtrap</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="slide-item">
                    	<div class="inner">
                        	<div class="speakers clearfix">
                            	<div class="speaker">
                                	<div class="image img-circle"><figure class="speaker-image img-circle"><img class="img-circle" src="images/resource/speaker-thumb-1.jpg" alt=""><a href="#" class="over-link"><span class="flaticon-plus-symbol"></span></a></figure></div>
                                    <div class="lower">
                                    	<div class="time">10am - 12pm</div>
                                        <div class="speaker-title">DAVID JHONSHON</div>
                                        <div class="designation">UX/ UI Designer</div>
                                    </div>
                                </div>
                                <div class="speaker">
                                	<div class="image img-circle"><figure class="speaker-image img-circle"><img class="img-circle" src="images/resource/speaker-thumb-2.jpg" alt=""><a href="#" class="over-link"><span class="flaticon-plus-symbol"></span></a></figure></div>
                                    <div class="lower">
                                    	<div class="time">09am - 12pm</div>
                                        <div class="speaker-title">WILLIAM JOHN</div>
                                        <div class="designation">Producer, CSI:Cyber</div>
                                    </div>
                                </div>
                                <div class="speaker">
                                	<div class="image img-circle"><figure class="speaker-image img-circle"><img class="img-circle" src="images/resource/speaker-thumb-3.jpg" alt=""><a href="#" class="over-link"><span class="flaticon-plus-symbol"></span></a></figure></div>
                                    <div class="lower">
                                    	<div class="time">09am - 12pm</div>
                                        <div class="speaker-title">CHELSIE</div>
                                        <div class="designation">CEO, Hatem Co.</div>
                                    </div>
                                </div>
                                <div class="speaker">
                                	<div class="image img-circle"><figure class="speaker-image img-circle"><img class="img-circle" src="images/resource/speaker-thumb-4.jpg" alt=""><a href="#" class="over-link"><span class="flaticon-plus-symbol"></span></a></figure></div>
                                    <div class="lower">
                                    	<div class="time">11am - 01pm</div>
                                        <div class="speaker-title">JEFF SEVERIN</div>
                                        <div class="designation">GM, The boxtrap</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="slide-item">
                    	<div class="inner">
                        	<div class="speakers clearfix">
                            	<div class="speaker">
                                	<div class="image img-circle"><figure class="speaker-image img-circle"><img class="img-circle" src="images/resource/speaker-thumb-1.jpg" alt=""><a href="#" class="over-link"><span class="flaticon-plus-symbol"></span></a></figure></div>
                                    <div class="lower">
                                    	<div class="time">10am - 12pm</div>
                                        <div class="speaker-title">DAVID JHONSHON</div>
                                        <div class="designation">UX/ UI Designer</div>
                                    </div>
                                </div>
                                <div class="speaker">
                                	<div class="image img-circle"><figure class="speaker-image img-circle"><img class="img-circle" src="images/resource/speaker-thumb-2.jpg" alt=""><a href="#" class="over-link"><span class="flaticon-plus-symbol"></span></a></figure></div>
                                    <div class="lower">
                                    	<div class="time">09am - 12pm</div>
                                        <div class="speaker-title">WILLIAM JOHN</div>
                                        <div class="designation">Producer, CSI:Cyber</div>
                                    </div>
                                </div>
                                <div class="speaker">
                                	<div class="image img-circle"><figure class="speaker-image img-circle"><img class="img-circle" src="images/resource/speaker-thumb-3.jpg" alt=""><a href="#" class="over-link"><span class="flaticon-plus-symbol"></span></a></figure></div>
                                    <div class="lower">
                                    	<div class="time">09am - 12pm</div>
                                        <div class="speaker-title">CHELSIE</div>
                                        <div class="designation">CEO, Hatem Co.</div>
                                    </div>
                                </div>
                                <div class="speaker">
                                	<div class="image img-circle"><figure class="speaker-image img-circle"><img class="img-circle" src="images/resource/speaker-thumb-4.jpg" alt=""><a href="#" class="over-link"><span class="flaticon-plus-symbol"></span></a></figure></div>
                                    <div class="lower">
                                    	<div class="time">11am - 01pm</div>
                                        <div class="speaker-title">JEFF SEVERIN</div>
                                        <div class="designation">GM, The boxtrap</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>

            </div>

        </div>
    </section>
    <!--End Schedule Section-->


    <!--Price Section-->
    <div class="price-section">
    	<div class="auto-container">
        	<!--Sec Title-->
            <div class="sec-title centered">
            	<h2>Our Pricing</h2>
                <h3>Tickets</h3>
                <div class="text">Nunc commodo tellus diam, sed molestie quam fermentum varius. Etiam finibus lorem vel interdum volutpat. Suspendisse lorem vel interdum volutpat. Suspendisse  </div>
            </div>
            <div class="row clearfix">

            	<!--Price Column-->
                <div class="price-column col-md-3 col-sm-6 col-xs-12">
                	<div class="inner-box">
                    	<div class="upper-box">
                        	<h2>Basic</h2>
                            <div class="price"><sup>$</sup>78</div>
                            <div class="time-duration">Per Week</div>
                        </div>
                        <!--Middle Box-->
                        <div class="middle-box">
                        	<ul>
                            	<li><a href="#">Visit 3 Event</a></li>
                                <li><a href="#">Regular Seat</a></li>
                                <li><a href="#">Lunch Item</a></li>
                                <li><a href="#">Free Entrance</a></li>
                            </ul>
                        </div>
                        <a href="#" class="theme-btn buy-btn">buy now</a>
                    </div>
                </div>

                <!--Price Column-->
                <div class="price-column col-md-3 col-sm-6 col-xs-12">
                	<div class="inner-box">
                    	<div class="upper-box">
                        	<h2>Premium</h2>
                            <div class="price"><sup>$</sup>110</div>
                            <div class="time-duration">Per Week</div>
                        </div>
                        <!--Middle Box-->
                        <div class="middle-box">
                        	<ul>
                            	<li><a href="#">Visit 3 Event</a></li>
                                <li><a href="#">Regular Seat</a></li>
                                <li><a href="#">Lunch Item</a></li>
                                <li><a href="#">Free Entrance</a></li>
                            </ul>
                        </div>
                        <a href="#" class="theme-btn buy-btn">buy now</a>
                    </div>
                </div>

                <!--Price Column-->
                <div class="price-column col-md-3 col-sm-6 col-xs-12">
                	<div class="inner-box">
                    	<div class="upper-box">
                        	<h2>Silver Pass</h2>
                            <div class="price"><sup>$</sup>120</div>
                            <div class="time-duration">Per Week</div>
                        </div>
                        <!--Middle Box-->
                        <div class="middle-box">
                        	<ul>
                            	<li><a href="#">Visit 3 Event</a></li>
                                <li><a href="#">Regular Seat</a></li>
                                <li><a href="#">Lunch Item</a></li>
                                <li><a href="#">Free Entrance</a></li>
                            </ul>
                        </div>
                        <a href="#" class="theme-btn buy-btn">buy now</a>
                    </div>
                </div>

                <!--Price Column-->
                <div class="price-column col-md-3 col-sm-6 col-xs-12">
                	<div class="inner-box">
                    	<div class="upper-box">
                        	<h2>Gold</h2>
                            <div class="price"><sup>$</sup>135</div>
                            <div class="time-duration">Per Week</div>
                        </div>
                        <!--Middle Box-->
                        <div class="middle-box">
                        	<ul>
                            	<li><a href="#">Visit 3 Event</a></li>
                                <li><a href="#">Regular Seat</a></li>
                                <li><a href="#">Lunch Item</a></li>
                                <li><a href="#">Free Entrance</a></li>
                            </ul>
                        </div>
                        <a href="#" class="theme-btn buy-btn">buy now</a>
                    </div>
                </div>

            </div>
        </div>
    </div>
    <!--End Price Section-->

    <!--Gallery Section-->
    <section class="gallery-section">
    	<div class="outer-box">
        	<div class="clearfix">
            	<!--Title Column-->
            	<div class="title-column">
                	<div class="title-inner">
                    	<div class="sec-title light centered">
                        	<h2>Our Gallery</h2>
                            <h3>Photos</h3>
                            <div class="text">There are many variations of passages of Lorem Ipsum available majority have. Ipsum available majority have. </div>
                        </div>
                        <a class="view-work" href="gallery.html">View All Works <span class="icon fa fa-angle-right"></span></a>
                    </div>
                </div>
                <div class="gallery-column">
                	<div class="three-item-carousel owl-carousel owl-theme">

                        <!--Gallery Item-->
                        <div class="gallery-item">
                            <div class="inner-box">
                                <div class="image-box">
                                    <img src="images/gallery/1.jpg" alt="" />
                                    <div class="overlay-box">
                                        <div class="portfolio-links">
                                            <a href="images/gallery/1.jpg" data-fancybox-group="default-gallery" class="plus-icon lightbox-image flaticon-plus-symbol" title="Image Caption Here"></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!--Gallery Item-->
                        <div class="gallery-item">
                            <div class="inner-box">
                                <div class="image-box">
                                    <img src="images/gallery/2.jpg" alt="" />
                                    <div class="overlay-box">
                                        <div class="portfolio-links">
                                            <a href="images/gallery/2.jpg" data-fancybox-group="default-gallery" class="plus-icon lightbox-image flaticon-plus-symbol" title="Image Caption Here"></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!--Gallery Item-->
                        <div class="gallery-item">
                            <div class="inner-box">
                                <div class="image-box">
                                    <img src="images/gallery/3.jpg" alt="" />
                                    <div class="overlay-box">
                                        <div class="portfolio-links">
                                            <a href="images/gallery/3.jpg" data-fancybox-group="default-gallery" class="plus-icon lightbox-image flaticon-plus-symbol" title="Image Caption Here"></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!--Gallery Item-->
                        <div class="gallery-item">
                            <div class="inner-box">
                                <div class="image-box">
                                    <img src="images/gallery/1.jpg" alt="" />
                                    <div class="overlay-box">
                                        <div class="portfolio-links">
                                            <a href="images/gallery/1.jpg" data-fancybox-group="default-gallery" class="plus-icon lightbox-image flaticon-plus-symbol" title="Image Caption Here"></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!--Gallery Item-->
                        <div class="gallery-item">
                            <div class="inner-box">
                                <div class="image-box">
                                    <img src="images/gallery/2.jpg" alt="" />
                                    <div class="overlay-box">
                                        <div class="portfolio-links">
                                            <a href="images/gallery/2.jpg" data-fancybox-group="default-gallery" class="plus-icon lightbox-image flaticon-plus-symbol" title="Image Caption Here"></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!--Gallery Item-->
                        <div class="gallery-item">
                            <div class="inner-box">
                                <div class="image-box">
                                    <img src="images/gallery/3.jpg" alt="" />
                                    <div class="overlay-box">
                                        <div class="portfolio-links">
                                            <a href="images/gallery/3.jpg" data-fancybox-group="default-gallery" class="plus-icon lightbox-image flaticon-plus-symbol" title="Image Caption Here"></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--End Gallery Section-->

    <!--News Section-->
    <section class="news-section">
    	<div class="auto-container">
        	<!--Sec Title-->
            <div class="sec-title centered">
            	<h2>Latest News</h2>
                <h3>Blog</h3>
                <div class="text">Nunc commodo tellus diam, sed molestie quam fermentum varius. Etiam finibus lorem vel interdum volutpat. Suspendisse lorem vel interdum volutpat. Suspendisse  </div>
            </div>
            <div class="row clearfix">

                <!--News Style One-->
                <div class="news-style-one col-md-4 col-sm-6 col-xs-12">
                	<div class="inner-box">
                    	<div class="image">
                        	<a href="blog-single.html"><img src="images/resource/news-1.jpg" alt="" /></a>
                        </div>
                        <div class="lower-box">
                        	<h3><a href="blog-single.html">MAKE IT CLEAN & SIMPLE</a></h3>
                            <ul class="post-meta">
                            	<li>by Jane Doe</li>
                                <li>Conference</li>
                                <li>Feb 23, 2017</li>
                            </ul>
                            <div class="text">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse lorem arcu, varius at porta vitae, dictumLorem ipsum.</div>
                            <a href="blog-single.html" class="read-more">READ MORE</a>
                        </div>
                    </div>
                </div>

                <!--News Style One-->
                <div class="news-style-one col-md-4 col-sm-6 col-xs-12">
                	<div class="inner-box">
                    	<div class="image">
                        	<a href="blog-single.html"><img src="images/resource/news-2.jpg" alt="" /></a>
                        </div>
                        <div class="lower-box">
                        	<h3><a href="blog-single.html">PLACES TO GET LOST</a></h3>
                            <ul class="post-meta">
                            	<li>by Jane Doe</li>
                                <li>Conference</li>
                                <li>Mar 16, 2017</li>
                            </ul>
                            <div class="text">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse lorem arcu, varius at porta vitae, dictumLorem ipsum.</div>
                            <a href="blog-single.html" class="read-more">READ MORE</a>
                        </div>
                    </div>
                </div>

                <!--News Style One-->
                <div class="news-style-one col-md-4 col-sm-6 col-xs-12">
                	<div class="inner-box">
                    	<div class="image">
                        	<a href="blog-single.html"><img src="images/resource/news-3.jpg" alt="" /></a>
                        </div>
                        <div class="lower-box">
                        	<h3><a href="blog-single.html">Scaling into crowded space</a></h3>
                            <ul class="post-meta">
                            	<li>by Jane Doe</li>
                                <li>Conference</li>
                                <li>Mar 22, 2017</li>
                            </ul>
                            <div class="text">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse lorem arcu, varius at porta vitae, dictumLorem ipsum.</div>
                            <a href="blog-single.html" class="read-more">READ MORE</a>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </section>
    <!--End News Section-->

    <!--Main Footer-->
    <footer class="main-footer footer-style-two">
    	<div class="auto-container">

            <!--Widgets Section-->
            <div class="widgets-section">
            	<div class="row clearfix">

                	<!--Big Column-->
                    <div class="big-column col-md-6 col-sm-12 col-xs-12">
                    	<div class="row clearfix">

                            <!--Footer Column-->
                            <div class="footer-column col-md-6 col-sm-6 col-xs-12">
                                <div class="footer-widget logo-widget">
                                    <div class="footer-logo"><figure><a href="index-2.html"><img src="images/footer-logo-2.png" alt=""></a></figure></div>
                                    <div class="widget-content">
                                        <div class="text">Aorem ipsum dolor sit amet elit sed lum tempor incididunt ut labore el dolore alg minim veniam quis nostrud ncididunt.</div>
                                        <a href="#" class="read-more">Read More <span class="icon fa fa-long-arrow-right"></span></a>
                                    </div>
                                </div>
                            </div>

                            <!--Footer Column-->
                            <div class="footer-column col-md-6 col-sm-6 col-xs-12">
                                <div class="footer-widget links-widget">
                                	<h2>Quick Links</h2>
                                    <div class="widget-content">
                                    	<ul class="list">
                                            <li><a href="#">About Conference</a></li>
                                            <li><a href="#">Our Speakers</a></li>
                                            <li><a href="#">Event Shedule</a></li>
                                            <li><a href="#">Latest News</a></li>
                                            <li><a href="#">Event Photo Gallery</a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>

                    <!--Big Column-->
                    <div class="big-column col-md-6 col-sm-12 col-xs-12">
                    	<div class="row clearfix">

                            <!--Footer Column-->
                            <div class="footer-column col-md-6 col-sm-6 col-xs-12">
                            	<div class="footer-widget posts-widget">
                                	<h2>Recent News</h2>
                                    <div class="widget-content">
                                    	<div class="posts">
                                            <div class="post">
                                                <figure class="post-thumb"><img src="images/resource/post-thumb-1.jpg" alt=""></figure>
                                                <div class="desc-text"><a href="blog-single.html">Rhythm of Strings 2015</a></div>
                                                <div class="time">By Adam Rose</div>
                                            </div>
                                            <div class="post">
                                                <figure class="post-thumb"><img src="images/resource/post-thumb-2.jpg" alt=""></figure>
                                                <div class="desc-text"><a href="blog-single.html">Strategy For Treatment</a></div>
                                                <div class="time">By Adam Rose</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!--Footer Column-->
                            <div class="footer-column col-md-6 col-sm-6 col-xs-12">
                            	<div class="footer-widget gallery-widget">
                                	<h2>Events Gallery</h2>
                                    <div class="images-outer clearfix">
                                        <!--Image Box-->
                                        <figure class="image-box"><a href="images/gallery/1.jpg" class="lightbox-image" title="Image Title Here" data-fancybox-group="footer-gallery"><img src="images/resource/footer-thumb-1.jpg" alt=""></a></figure>
                                        <!--Image Box-->
                                        <figure class="image-box"><a href="images/gallery/2.jpg" class="lightbox-image" title="Image Title Here" data-fancybox-group="footer-gallery"><img src="images/resource/footer-thumb-2.jpg" alt=""></a></figure>
                                        <!--Image Box-->
                                        <figure class="image-box"><a href="images/gallery/3.jpg" class="lightbox-image" title="Image Title Here" data-fancybox-group="footer-gallery"><img src="images/resource/footer-thumb-3.jpg" alt=""></a></figure>
                                        <!--Image Box-->
                                        <figure class="image-box"><a href="images/gallery/1.jpg" class="lightbox-image" title="Image Title Here" data-fancybox-group="footer-gallery"><img src="images/resource/footer-thumb-4.jpg" alt=""></a></figure>
                                        <!--Image Box-->
                                        <figure class="image-box"><a href="images/gallery/2.jpg" class="lightbox-image" title="Image Title Here" data-fancybox-group="footer-gallery"><img src="images/resource/footer-thumb-5.jpg" alt=""></a></figure>
                                        <!--Image Box-->
                                        <figure class="image-box"><a href="images/gallery/3.jpg" class="lightbox-image" title="Image Title Here" data-fancybox-group="footer-gallery"><img src="images/resource/footer-thumb-6.jpg" alt=""></a></figure>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>

                </div>
            </div>

        	<!--Footer Info Section-->
        	<div class="footer-info-section">
            	<div class="row clearfix">
                	<!--Column-->
                	<div class="column col-md-4 col-sm-6 col-xs-12">
                    	<div class="footer-info">
                        	<div class="inner">
                            	<div class="icon flaticon-location-pin"></div>
                                <div class="text">184 Collins Street West Victoria, United States, 8007</div>
                            </div>
                        </div>
                    </div>

                    <!--Column-->
                	<div class="column col-md-4 col-sm-6 col-xs-12">
                    	<div class="footer-info">
                        	<div class="inner">
                            	<div class="icon flaticon-smartphone-1"></div>
                                <div class="text">(1800) 123 4567 <br> (1800) 123 4568</div>
                            </div>
                        </div>
                    </div>

                    <!--Column-->
                	<div class="column col-md-4 col-sm-6 col-xs-12">
                    	<div class="footer-info">
                        	<div class="inner">
                            	<div class="icon flaticon-envelope"></div>
                                <div class="text">Info@torino.com <br> Support@Torino.com</div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>

        </div>
        <!--Footer Bottom-->
        <div class="footer-bottom">
        	<div class="auto-container">
            	<div class="row clearfix">
                	<div class="column col-md-6 col-sm-12 col-xs-12">
                    	<div class="copyright">COPYRIGHT &copy; 2017 Torino. ALL RIGHTS RESERVED</div>
                    </div>
                    <div class="column col-md-6 col-sm-12 col-xs-12">
                    	<ul class="social-icon-four">
                            <li><a href="#"><span class="fa fa-facebook"></span></a></li>
                            <li><a href="#"><span class="fa fa-twitter"></span></a></li>
                            <li><a href="#"><span class="fa fa-instagram"></span></a></li>
                            <li><a href="#"><span class="fa fa-google-plus"></span></a></li>
                            <li><a href="#"><span class="fa fa-linkedin"></span></a></li>
                            <li><a href="#"><span class="fa fa-pinterest-p"></span></a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!--End Main Footer-->

</div>
<!--End pagewrapper-->

<!--Scroll to top-->
<div class="scroll-to-top scroll-to-target" data-target=".main-header"><span class="icon fa fa-long-arrow-up"></span></div>

 


<script src="/js/jquery.js"></script>
<script src="/js/bootstrap.min.js"></script>
<script src="/js/revolution.min.js"></script>
<script src="/js/jquery-ui.js"></script>
<script src="/js/jquery.fancybox.pack.js"></script>
<script src="/js/jquery.fancybox-media.js"></script>
<script src="/js/owl.js"></script>
<script src="/js/wow.js"></script>
<script src="/js/appear.js"></script>
<script src="/js/jquery.countdown.js"></script>
<script src="/js/script.js"></script>

<!--Color Switcher Script-->
<script src="js/color-settings.js"></script>
</body>

<!-- Mirrored from t.commonsupport.com/torino/index-2.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 08 Aug 2017 12:39:48 GMT -->
</html>
