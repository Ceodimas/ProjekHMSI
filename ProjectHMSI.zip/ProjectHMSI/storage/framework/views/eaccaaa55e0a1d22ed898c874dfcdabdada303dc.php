<?php $__env->startSection('title', 'Departemen Enterpreneur'); ?>

<?php $__env->startSection('content'); ?>
 
            
   
    
    <!--About Section Two-->
    <section class="about-section-two">
        <div class="auto-container">
            <div class="row clearfix">
                <!--Content Column-->
                <div class="content-column col-md-6 col-sm-12 col-xs-12">
                    <div class="inner">
                        <div class="about-title">
                        <div class="sub-title">Deskripsi</div>
                        <h2>Departemen Enterpreneur</h2>
                        </div>
                        
                        <div class="text">
                        Departemen Enterpreneur adalah Ujung tombak himpunan dalam pencarian dana yang akan digunakan untuk membiayai seluruh operasional himpunan.
                        
                        

                        <h2>Program Kerja</h2>
                    1.	Baju jurusan<br>
					2.	JAKET HIMPUNAN SI<br>
					3.	Merchandise Sistem Informasi dan #CyanInvasion<br>
					4.	Wisuda<br>
					5.	Seragam SI<br>
					6.	Seminar EuIS (Entrepreneur Information Sistem)<br>



                        </div>

                    </div>
                </div>
                <!--Video Column-->
                <div class="video-column col-md-6 col-sm-12 col-xs-12">
                    <div class="video-box">
                        
                            <img src="images/Logo/logo-epr.png" alt="Departemen Enterpreneur">
                        
                      
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--End About Section Two-->
    <?php $__env->stopSection(); ?>


    <?php $__env->startSection('member'); ?>

    <!--Speaker Section-->
    <section class="speaker-section">
        <div class="auto-container">
            <!--Sec Title-->
            <div class="sec-title centered">
                <h2>Anggota Departemen Enterpreneur</h2>
                <h3>HMSI 2017-2018</h3>
             </div>
            <div class="four-item-carousel owl-carousel owl-theme">

                <!--Team Member Two-->
                <div class="team-member-two">
                    <div class="inner-box">
                        <div class="image">
                            <img src="images/Anggota/EPR/EPR-1.png"/>
                         </div>
                        <div class="lower-info">
                            <h3>NAMA ANGGOTA </h3>
                            
                        </div>
                    </div>
                </div>

                <!--Team Member Two-->
                <div class="team-member-two">
                    <div class="inner-box">
                        <div class="image">
                            <img src="images/Anggota/EPR/EPR-1.png"/>
                         </div>
                        <div class="lower-info">
                            <h3>NAMA ANGGOTA </h3>
                            
                        </div>
                    </div>
                </div>
                                <!--Team Member Two-->
                <div class="team-member-two">
                    <div class="inner-box">
                        <div class="image">
                            <img src="images/Anggota/EPR/EPR-1.png"/>
                         </div>
                        <div class="lower-info">
                            <h3>NAMA ANGGOTA </h3>
                            
                        </div>
                    </div>
                </div>
                                <!--Team Member Two-->
                <div class="team-member-two">
                    <div class="inner-box">
                        <div class="image">
                            <img src="images/Anggota/EPR/EPR-1.png"/>
                         </div>
                        <div class="lower-info">
                            <h3>NAMA ANGGOTA </h3>
                            
                        </div>
                    </div>
                </div>
                                <!--Team Member Two-->
                <div class="team-member-two">
                    <div class="inner-box">
                        <div class="image">
                            <img src="images/Anggota/EPR/EPR-1.png"/>
                         </div>
                        <div class="lower-info">
                            <h3>NAMA ANGGOTA </h3>
                            
                        </div>
                    </div>
                </div> 

               
 
    </section>
    <!--End Speaker Section-->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.hmsi-app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>