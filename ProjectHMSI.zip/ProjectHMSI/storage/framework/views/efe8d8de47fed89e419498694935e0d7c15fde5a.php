<?php $__env->startSection('title', 'Departemen Akademik'); ?>

<?php $__env->startSection('content'); ?>
  
   
    
    <!--About Section Two-->
    <section class="about-section-two">
        <div class="auto-container">
            <div class="row clearfix">
                <!--Content Column-->
                <div class="content-column col-md-6 col-sm-12 col-xs-12">
                    <div class="inner">
                        <div class="about-title">
                        <div class="sub-title">Deskripsi</div>
                        <h2>Departemen Akademik</h2>
                        </div>
                        
                        <div class="text">
                        Departemen Akademik adalah departemen yang bertugas untuk menjaga stabilitas dan meningkatkan kualitas akademik mahasiswa Sistem Informasi.
                        
                        

                        <h2>Program Kerja</h2>
                        1.   SALE HMSI (Sharing File)<br>
                        2.  TenCom (Tentor Comunity)<br>
                        3.  Responsi<br>
                        4.  AmuniSI<br>
                        5.  Gubuk HMSI ( Gudang Buku HMSI )<br>

                        </div>

                    </div>
                </div>
                <!--Video Column-->
                <div class="video-column col-md-6 col-sm-12 col-xs-12">
                    <div class="video-box">
                        
                            <img src="images/Logo/logo-Akademik.png" alt="Departemen Akademik">
                        
                      
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--End About Section Two-->
    <?php $__env->stopSection(); ?>


    <?php $__env->startSection('member'); ?>

    <!--Speaker Section-->
    <section class="speaker-section">
        <div class="auto-container">
            <!--Sec Title-->
            <div class="sec-title centered">
                <h2>Anggota Departemen Akademik</h2>
                <h3>HMSI 2017-2018</h3>
             </div>
            <div class="four-item-carousel owl-carousel owl-theme">

                <!--Team Member Two-->
                <div class="team-member-two">
                    <div class="inner-box">
                        <div class="image">
                            <img src="images/Anggota/AKADEMIK/AKADEMIK-1.png"/>
                         </div>
                        <div class="lower-info">
                            <h3>RAHMANIA ARINA</h3>
                            
                        </div>
                    </div>
                </div>

                <!--Team Member Two-->
                <div class="team-member-two">
                    <div class="inner-box">
                        <div class="image">
                            <img src="images/Anggota/AKADEMIK/AKADEMIK-2.png"   />
                         </div>
                        <div class="lower-info">
                            <h3>RAMONA DWI UTARI</h3>
                            
                        </div>
                    </div>
                </div>


                <!--Team Member Two-->
                <div class="team-member-two">
                    <div class="inner-box">
                        <div class="image">
                            <img src="images/Anggota/AKADEMIK/AKADEMIK-3.png"   />
                         </div>
                        <div class="lower-info">
                            <h3>AJI NUR LAKSONO</h3>
                            
                        </div>
                    </div>
                </div>


                <!--Team Member Two-->
                <div class="team-member-two">
                    <div class="inner-box">
                        <div class="image">
                            <img src="images/Anggota/AKADEMIK/AKADEMIK-4.png"  />
                         </div>
                        <div class="lower-info">
                            <h3>BIMA ADJI</h3>
                            
                        </div>
                    </div>
                </div>


                <!--Team Member Two-->
                <div class="team-member-two">
                    <div class="inner-box">
                        <div class="image">
                            <img src="images/Anggota/AKADEMIK/AKADEMIK-5.png"   />
                         </div>
                        <div class="lower-info">
                            <h3>DHEA KHAIRANI Z</h3>
                            
                        </div>
                    </div>
                </div>

        <!--Team Member Two-->
                <div class="team-member-two">
                    <div class="inner-box">
                        <div class="image">
                            <img src="images/Anggota/AKADEMIK/AKADEMIK-6.png"  />
                         </div>
                        <div class="lower-info">
                            <h3>EDITHA DEWI</h3>
                            
                        </div>
                    </div>
                </div>                

                <!--Team Member Two-->
                <div class="team-member-two">
                    <div class="inner-box">
                        <div class="image">
                            <img src="images/Anggota/AKADEMIK/AKADEMIK-7.png" />
                         </div>
                        <div class="lower-info">
                            <h3>ERY ERYANTO</h3>
                            
                        </div>
                    </div>
                </div>

               
 
    </section>
    <!--End Speaker Section-->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.hmsi-app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>