<?php $__env->startSection('title', 'Departemen Komunikasi dan Informasi'); ?>

<?php $__env->startSection('content'); ?>
 
   
    
    <!--About Section Two-->
    <section class="about-section-two">
        <div class="auto-container">
            <div class="row clearfix">
                <!--Content Column-->
                <div class="content-column col-md-6 col-sm-12 col-xs-12">
                    <div class="inner">
                        <div class="about-title">
                        <div class="sub-title">Deskripsi</div>
                        <h2>Departemen Komunikasi dan Informasi</h2>
                        </div>
                        
                        <div class="text">
                        Departemen Komunikasi dan Informasi adalah Departemen yang bertugas membuat sistem penyebaran informasi yang ada di dalam HMSI Unitel dan memastikan arus penyebaran informasi yang ada di dalam maupun luar HMSI Unitel berjalan dengan baik dan tersebar secara merata.
                        
                        

                        <h2>Program Kerja</h2>
            	1.	D-ARM (Digital Art and Marketing)<br>
				2.	Multimedia Content Academy (MCA)<br>
				3.	Final Project<br>





                        </div>

                    </div>
                </div>
                <!--Video Column-->
                <div class="video-column col-md-6 col-sm-12 col-xs-12">
                    <div class="video-box">
                        
                            <img src="images/Logo/logo-kominfo.png" alt="Departemen Komunikasi dan Informasi">
                        
                      
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--End About Section Two-->
    <?php $__env->stopSection(); ?>


    <?php $__env->startSection('member'); ?>

    <!--Speaker Section-->
    <section class="speaker-section">
        <div class="auto-container">
            <!--Sec Title-->
            <div class="sec-title centered">
                <h2>Anggota Departemen Komunikasi dan Informasi</h2>
                <h3>HMSI 2017-2018</h3>
             </div>
            <div class="four-item-carousel owl-carousel owl-theme">

                <!--Team Member Two-->
                <div class="team-member-two">
                    <div class="inner-box">
                        <div class="image">
                            <img src="images/Anggota/KOMINFO/KOMINFO-1.png"/>
                         </div>
                        <div class="lower-info">
                            <h3>RIFFAN FAUZIA</h3>
                            
                        </div>
                    </div>
                </div>

                <!--Team Member Two-->
                <div class="team-member-two">
                    <div class="inner-box">
                        <div class="image">
                            <img src="images/Anggota/KOMINFO/KOMINFO-2.png"/>
                         </div>
                        <div class="lower-info">
                            <h3>MAISHA</h3>
                            
                        </div>
                    </div>
                </div>
                                <!--Team Member Two-->
                <div class="team-member-two">
                    <div class="inner-box">
                        <div class="image">
                            <img src="images/Anggota/KOMINFO/KOMINFO-3.png"/>
                         </div>
                        <div class="lower-info">
                            <h3>HAMDANI </h3>
                            
                        </div>
                    </div>
                </div>
                                <!--Team Member Two-->
                <div class="team-member-two">
                    <div class="inner-box">
                        <div class="image">
                            <img src="images/Anggota/KOMINFO/KOMINFO-4.png"/>
                         </div>
                        <div class="lower-info">
                            <h3>NANDITYA </h3>
                            
                        </div>
                    </div>
                </div>
                                <!--Team Member Two-->
                <div class="team-member-two">
                    <div class="inner-box">
                        <div class="image">
                            <img src="images/Anggota/KOMINFO/KOMINFO-5.png"/>
                         </div>
                        <div class="lower-info">
                            <h3>DICKY YUDA H </h3>
                            
                        </div>
                    </div>
                </div> 

               
 
    </section>
    <!--End Speaker Section-->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.hmsi-app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>