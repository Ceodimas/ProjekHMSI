@extends('layout.hmsi-app')


@section('title', 'Departemen Riset dan Teknologi')

@section('content')
 
            
   
    
    <!--About Section Two-->
    <section class="about-section-two">
        <div class="auto-container">
            <div class="row clearfix">
                <!--Content Column-->
                <div class="content-column col-md-6 col-sm-12 col-xs-12">
                    <div class="inner">
                        <div class="about-title">
                        <div class="sub-title">Deskripsi</div>
                        <h2>Departemen Riset dan Teknologi</h2>
                        </div>
                        
                        <div class="text">
                        Departemen Riset dan Teknologi adalah Departemen yang Mewadahi kebutuhan lab dan keprofesian, menunjang kegiatan riset grup dan project-project yang dari lab, keprofesian, riset grup mahasiswa Sistem informasi, dan memaksimalkan pemanfaatan teknologi sebagai support system dalam kegiatan-kegiatan HMSI.
                        

                        <h2>Program Kerja</h2>
           				1.	WEBSITE HMSI <br>
						2.	WEBSITE Indigolabs<br>
						3.	Mobile Apps HMSI<br>
						4.	PKM<br>





                        </div>

                    </div>
                </div>
                <!--Video Column-->
                <div class="video-column col-md-6 col-sm-12 col-xs-12">
                    <div class="video-box">
                        
                            <img src="images/Logo/logo-ristek.png" alt="Departemen Riset dan Teknologi">
                        
                      
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--End About Section Two-->
    @endsection


    @section('member')

    <!--Speaker Section-->
    <section class="speaker-section">
        <div class="auto-container">
            <!--Sec Title-->
            <div class="sec-title centered">
                <h2>Anggota Departemen Riset dan Teknologi</h2>
                <h3>HMSI 2017-2018</h3>
             </div>
            <div class="four-item-carousel owl-carousel owl-theme">
         		
         		<!--Team Member Two-->
                <div class="team-member-two">
                    <div class="inner-box">
                        <div class="image">
                            <img src="images/Anggota/RISTEK/RISTEK-2.png"/>
                         </div>
                        <div class="lower-info">
                            <h3>RANDY EKA SAPUTRA</h3>
                            
                        </div>
                    </div>
                </div>

                <!--Team Member Two-->
                <div class="team-member-two">
                    <div class="inner-box">
                        <div class="image">
                            <img src="images/Anggota/RISTEK/RISTEK-1.png"/>
                         </div>
                        <div class="lower-info">
                            <h3>ARIEF HAKIM</h3>
                            
                        </div>
                    </div>
                </div>

       
                                <!--Team Member Two-->
                <div class="team-member-two">
                    <div class="inner-box">
                        <div class="image">
                            <img src="images/Anggota/RISTEK/RISTEK-3.png"/>
                         </div>
                        <div class="lower-info">
                            <h3>PAGESTU TITAN</h3>
                            
                        </div>
                    </div>
                </div>
                                <!--Team Member Two-->
                <div class="team-member-two">
                    <div class="inner-box">
                        <div class="image">
                            <img src="images/Anggota/RISTEK/RISTEK-4.png"/>
                         </div>
                        <div class="lower-info">
                            <h3>DIMAS DWI CAHYA </h3>
                            
                        </div>
                    </div>
                </div>
                                <!--Team Member Two-->
                <div class="team-member-two">
                    <div class="inner-box">
                        <div class="image">
                            <img src="images/Anggota/RISTEK/RISTEK-5.png"/>
                         </div>
                        <div class="lower-info">
                            <h3>M. AFIFUDIN </h3>
                            
                        </div>
                    </div>
                </div> 


                                <!--Team Member Two-->
                <div class="team-member-two">
                    <div class="inner-box">
                        <div class="image">
                            <img src="images/Anggota/RISTEK/RISTEK-6.png"/>
                         </div>
                        <div class="lower-info">
                            <h3>YOEL TAMPUBOLON </h3>
                            
                        </div>
                    </div>
                </div>                 

               
 
    </section>
    <!--End Speaker Section-->

@endsection
