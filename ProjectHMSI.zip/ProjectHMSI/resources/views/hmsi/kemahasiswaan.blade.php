@extends('layout.hmsi-app')


@section('title', 'Departemen Kemahasiswaan')

@section('content')
 
    		
   
    
    <!--About Section Two-->
    <section class="about-section-two">
    	<div class="auto-container">
        	<div class="row clearfix">
            	<!--Content Column-->
                <div class="content-column col-md-6 col-sm-12 col-xs-12">
                	<div class="inner">
                    	<div class="about-title">
                        <div class="sub-title">Deskripsi</div>
                        <h2>Departemen Kemahasiswaan</h2>
                        </div>
                        
                        <div class="text">
                        Departemen Kemahasiswaan adalah departemen yang memberikan pelayanan bagi mahasiswa Departemen Rekayasa Industri berupa sifat proaktif untuk menangani permasalahan dikalangan intern mahasiswa yang ada secara cepat dan up tu date. Dan bertanggung jawab terhadap kegiatan intern mahasiswa Sistem Informasi terutama yang menjadi ekspektasi mahasiswa SI.
                        
                        

                        <h2>Program Kerja</h2>
                        1.	IS-WP  (Welcoming Party)<br>
						2.	TPB HEROES<br>
						3.	CEREMONY<br>
						4.	KYIS (Know Your Information System)<br>
						5.	PSI (Persatuan Olahraga Sistem Informasi)<br>
						6.	INSYL (Information System League)<br>
						7.	HUT SI<br>
						</div>

                    </div>
                </div>
                <!--Video Column-->
                <div class="video-column col-md-6 col-sm-12 col-xs-12">
                	<div class="video-box">
                        
                            <img src="images/Logo/logo-Kemahasiswaan.png" alt="Departemen Kemahasiswaan">
                        
                      
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--End About Section Two-->
    @endsection


    @section('member')

    <!--Speaker Section-->
    <section class="speaker-section">
    	<div class="auto-container">
        	<!--Sec Title-->
            <div class="sec-title centered">
            	<h2>Anggota Departemen Kemahasiswaan</h2>
                <h3>HMSI 2017-2018</h3>
             </div>
            <div class="four-item-carousel owl-carousel owl-theme">

            	<!--Team Member Two-->
                <div class="team-member-two">
                	<div class="inner-box">
                    	<div class="image">
                        	<img src="images/Anggota/KAMSIS/KAMSIS-1.png"/>
                         </div>
                        <div class="lower-info">
                        	<h3>LUTFI RAUDHA</h3>
                            
                        </div>
                    </div>
                </div>

            	<!--Team Member Two-->
                <div class="team-member-two">
                	<div class="inner-box">
                    	<div class="image">
                        	<img src="images/Anggota/KAMSIS/KAMSIS-2.png" alt="Departemen Ristek" />
                         </div>
                        <div class="lower-info">
                        	<h3>RIGA</h3>
                            
                        </div>
                    </div>
                </div>


            	<!--Team Member Two-->
                <div class="team-member-two">
                	<div class="inner-box">
                    	<div class="image">
                        	<img src="images/Anggota/KAMSIS/KAMSIS-3.png" alt="Departemen Kemahasiswaan" />
                         </div>
                        <div class="lower-info">
                        	<h3>ARIQ ADYAVI</h3>
                            
                        </div>
                    </div>
                </div>


            	<!--Team Member Two-->
                <div class="team-member-two">
                	<div class="inner-box">
                    	<div class="image">
                        	<img src="images/Anggota/KAMSIS/KAMSIS-4.png" alt="Departemen HRD" />
                         </div>
                        <div class="lower-info">
                        	<h3>M. RASYID T</h3>
                            
                        </div>
                    </div>
                </div>


            	<!--Team Member Two-->
                <div class="team-member-two">
                	<div class="inner-box">
                    	<div class="image">
                        	<img src="images/Anggota/KAMSIS/KAMSIS-5.png"   />
                         </div>
                        <div class="lower-info">
                        	<h3>ANDIKA JULIAN</h3>
                            
                        </div>
                    </div>
                </div>

     	<!--Team Member Two-->
                <div class="team-member-two">
                	<div class="inner-box">
                    	<div class="image">
                        	<img src="images/Anggota/KAMSIS/KAMSIS-6.png"  />
                         </div>
                        <div class="lower-info">
                        	<h3>M GHAZIAN</h3>
                            
                        </div>
                    </div>
                </div>                

            	<!--Team Member Two-->
                <div class="team-member-two">
                	<div class="inner-box">
                    	<div class="image">
                        	<img src="images/Anggota/KAMSIS/KAMSIS-7.png" />
                         </div>
                        <div class="lower-info">
                        	<h3>CATUR SENA </h3>
                            
                        </div>
                    </div>
                </div>

            	<!--Team Member Two-->
                <div class="team-member-two">
                	<div class="inner-box">
                    	<div class="image">
                        	<img src="images/Anggota/KAMSIS/KAMSIS-8.png"/>
                         </div>
                        <div class="lower-info">
                        	<h3>RATIH</h3>
                            
                        </div>
                    </div>
                </div>


                <!--Team Member Two-->
                <div class="team-member-two">
                    <div class="inner-box">
                        <div class="image">
                            <img src="images/Anggota/KAMSIS/KAMSIS-9.png"/>
                         </div>
                        <div class="lower-info">
                            <h3>NADYA</h3>
                            
                        </div>
                    </div>
                </div>

                                <!--Team Member Two-->
                <div class="team-member-two">
                    <div class="inner-box">
                        <div class="image">
                            <img src="images/Anggota/KAMSIS/KAMSIS-10.png"/>
                         </div>
                        <div class="lower-info">
                            <h3>CANADYA</h3>
                            
                        </div>
                    </div>
                </div>

 
    </section>
    <!--End Speaker Section-->

@endsection
