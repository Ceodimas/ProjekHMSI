@extends('layout.hmsi-app')


@section('title', 'Departemen Kaderisasi')

@section('content')
 
    		
   
    
    <!--About Section Two-->
    <section class="about-section-two">
    	<div class="auto-container">
        	<div class="row clearfix">
            	<!--Content Column-->
                <div class="content-column col-md-6 col-sm-12 col-xs-12">
                	<div class="inner">
                    	<div class="about-title">
                        <div class="sub-title">Deskripsi</div>
                        <h2>Departemen Kaderisasi</h2>
                        </div>
                        
                        <div class="text">
                        Departemen Kaderisasi adalah departemen yang berfokus pada pembentukan karakter mahasiswa Sistem Informasi yang tangguh dan berkualitas dan siap untuk meneruskan kepengurusan organisasi khususnya HMSI.
                        
                        

                        <h2>Program Kerja</h2>
                        1.	GENESIS (Generation of Information System)<br>
						2.	STAFF MUDA HMSI<br>
						3.	PENJAKETAN<br>
						4.	TRAILER (Training About Leadership & Organization)<br>

				



						</div>

                    </div>
                </div>
                <!--Video Column-->
                <div class="video-column col-md-6 col-sm-12 col-xs-12">
                	<div class="video-box">
                        
                            <img src="images/Logo/logo-kaderisasi.png" alt="Departemen Kaderisasi">
                        
                      
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--End About Section Two-->
    @endsection


    @section('member')

    <!--Speaker Section-->
    <section class="speaker-section">
    	<div class="auto-container">
        	<!--Sec Title-->
            <div class="sec-title centered">
            	<h2>Anggota Departemen Kaderisasi</h2>
                <h3>HMSI 2017-2018</h3>
             </div>
            <div class="four-item-carousel owl-carousel owl-theme">

            	<!--Team Member Two-->
                <div class="team-member-two">
                	<div class="inner-box">
                    	<div class="image">
                        	<img src="images/Anggota/KDR/KDR-1.png"/>
                         </div>
                        <div class="lower-info">
                        	<h3>LINDA</h3>
                            
                        </div>
                    </div>
                </div>

            	<!--Team Member Two-->
                <div class="team-member-two">
                	<div class="inner-box">
                    	<div class="image">
                        	<img src="images/Anggota/KDR/KDR-2.png" alt="Departemen Ristek" />
                         </div>
                        <div class="lower-info">
                        	<h3>AULIA RAVI</h3>
                            
                        </div>
                    </div>
                </div>


            	<!--Team Member Two-->
                <div class="team-member-two">
                	<div class="inner-box">
                    	<div class="image">
                        	<img src="images/Anggota/KDR/KDR-3.png" alt="Departemen Kemahasiswaan" />
                         </div>
                        <div class="lower-info">
                        	<h3>FARIS</h3>
                            
                        </div>
                    </div>
                </div>


            	<!--Team Member Two-->
                <div class="team-member-two">
                	<div class="inner-box">
                    	<div class="image">
                        	<img src="images/Anggota/KDR/KDR-4.png" alt="Departemen HRD" />
                         </div>
                        <div class="lower-info">
                        	<h3>JAFAR HARITSAH</h3>
                            
                        </div>
                    </div>
                </div>


            	<!--Team Member Two-->
                <div class="team-member-two">
                	<div class="inner-box">
                    	<div class="image">
                        	<img src="images/Anggota/KDR/KDR-5.png" alt="Departemen Enterpreneur" />
                         </div>
                        <div class="lower-info">
                        	<h3>ARIF RAMDANI</h3>
                            
                        </div>
                    </div>
                </div>

     	<!--Team Member Two-->
                <div class="team-member-two">
                	<div class="inner-box">
                    	<div class="image">
                        	<img src="images/Anggota/KDR/KDR-6.png"  />
                         </div>
                        <div class="lower-info">
                        	<h3>IRMAYANTI SYAM</h3>
                            
                        </div>
                    </div>
                </div>                

            	<!--Team Member Two-->
                <div class="team-member-two">
                	<div class="inner-box">
                    	<div class="image">
                        	<img src="images/Anggota/KDR/KDR-7.png" />
                         </div>
                        <div class="lower-info">
                        	<h3>DEVALIA</h3>
                            
                        </div>
                    </div>
                </div>

            	<!--Team Member Two-->
                <div class="team-member-two">
                	<div class="inner-box">
                    	<div class="image">
                        	<img src="images/Anggota/KDR/KDR-8.png"/>
                         </div>
                        <div class="lower-info">
                        	<h3>LINGGA</h3>
                            
                        </div>
                    </div>
                </div>


                <!--Team Member Two-->
                <div class="team-member-two">
                    <div class="inner-box">
                        <div class="image">
                            <img src="images/Anggota/KDR/KDR-9.png"/>
                         </div>
                        <div class="lower-info">
                            <h3>BREGAS ARYA</h3>
                            
                        </div>
                    </div>
                </div>

                                <!--Team Member Two-->
                <div class="team-member-two">
                    <div class="inner-box">
                        <div class="image">
                            <img src="images/Anggota/KDR/KDR-10.png"/>
                         </div>
                        <div class="lower-info">
                            <h3>KOMALA BULQIS</h3>
                            
                        </div>
                    </div>
                </div>

                                <!--Team Member Two-->
                <div class="team-member-two">
                    <div class="inner-box">
                        <div class="image">
                            <img src="images/Anggota/KDR/KDR-11.png"/>
                         </div>
                        <div class="lower-info">
                            <h3>ADILA RAHMANSYAH</h3>
                            
                        </div>
                    </div>
                </div>
                                <!--Team Member Two-->
                <div class="team-member-two">
                    <div class="inner-box">
                        <div class="image">
                            <img src="images/Anggota/KDR/KDR-8"/>
                         </div>
                        <div class="lower-info">
                            <h3>LINGGA</h3>
                            
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </section>
    <!--End Speaker Section-->
 

 



@endsection
