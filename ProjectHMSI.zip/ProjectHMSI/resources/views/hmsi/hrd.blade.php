@extends('layout.hmsi-app')


@section('title', 'Departemen Human Resource Development')
 

  @section('content')

    <!--About Section Two-->
    <section class="about-section-two">
        <div class="auto-container">
            <div class="row clearfix">
                <!--Content Column-->
                <div class="content-column col-md-6 col-sm-12 col-xs-12">
                    <div class="inner">
                        <div class="about-title">
                        <div class="sub-title">Deskripsi</div>
                        <h2>Departemen Human Resource Development</h2>
                        </div>
                        
                        <div class="text">
                        Departemen Human Resource Development adalah Departemen yang bertugas menjaga kestabilan dan meningkatkan kinerja/performansi pengurus HMSI dalam menjalankan Program Kerja.
                        
                        

                        <h2>Program Kerja</h2>
            			1.	THR (Two Hours with HRD)<br>
						2.	BEHEL (Best Habits of Excellent Leader)<br>




                        </div>

                    </div>
                </div>
                <!--Video Column-->
                <div class="video-column col-md-6 col-sm-12 col-xs-12">
                    <div class="video-box">
                        
                            <img src="images/Logo/logo-hrd.png" alt="Departemen Human Resource Development">
                        
                      
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--End About Section Two-->
    @endsection


    @section('member')

    <!--Speaker Section-->
    <section class="speaker-section">
        <div class="auto-container">
            <!--Sec Title-->
            <div class="sec-title centered">
                <h2>Anggota Departemen Human Resource Development</h2>
                <h3>HMSI 2017-2018</h3>
             </div>
            <div class="four-item-carousel owl-carousel owl-theme">

                <!--Team Member Two-->
                <div class="team-member-two">
                    <div class="inner-box">
                        <div class="image">
                            <img src="images/Anggota/HRD/HRD-1.png"/>
                         </div>
                        <div class="lower-info">
                            <h3>NAMA ANGGOTA </h3>
                            
                        </div>
                    </div>
                </div>

                <!--Team Member Two-->
                <div class="team-member-two">
                    <div class="inner-box">
                        <div class="image">
                            <img src="images/Anggota/HRD/HRD-1.png"/>
                         </div>
                        <div class="lower-info">
                            <h3>NAMA ANGGOTA </h3>
                            
                        </div>
                    </div>
                </div>
                                <!--Team Member Two-->
                <div class="team-member-two">
                    <div class="inner-box">
                        <div class="image">
                            <img src="images/Anggota/HRD/HRD-1.png"/>
                         </div>
                        <div class="lower-info">
                            <h3>NAMA ANGGOTA </h3>
                            
                        </div>
                    </div>
                </div>
                                <!--Team Member Two-->
                <div class="team-member-two">
                    <div class="inner-box">
                        <div class="image">
                            <img src="images/Anggota/HRD/HRD-1.png"/>
                         </div>
                        <div class="lower-info">
                            <h3>NAMA ANGGOTA </h3>
                            
                        </div>
                    </div>
                </div>
                                <!--Team Member Two-->
                <div class="team-member-two">
                    <div class="inner-box">
                        <div class="image">
                            <img src="images/Anggota/HRD/HRD-1.png"/>
                         </div>
                        <div class="lower-info">
                            <h3>NAMA ANGGOTA </h3>
                            
                        </div>
                    </div>
                </div> 

               
 
    </section>
    <!--End Speaker Section-->

@endsection
