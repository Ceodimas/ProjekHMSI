<!DOCTYPE html>
<html>

<!-- Mirrored from t.commonsupport.com/torino/index-2.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 08 Aug 2017 12:39:07 GMT -->
<head>
<meta charset="utf-8">
<title>HMSI | @yield('title')</title>
<!-- Stylesheets -->




<link href="{{asset('/css/bootstrap.css')}}" rel="stylesheet">
<link href="{{asset('/css/revolution-slider.css')}}" rel="stylesheet">
<link href="{{asset('/css/jquery-ui.css')}}" rel="stylesheet">
<link href="{{asset('/css/style.css')}}" rel="stylesheet">
<link href="{{asset('/css/responsive.css')}}" rel="stylesheet">



<!--Color Switcher Mockup-->




<!--Color Themes-->
<link href="css/color-themes/blue-theme.css" rel="stylesheet">


<!--Favicon-->
<link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon">
<link rel="icon" href="images/favicon.ico" type="image/x-icon">
<!-- Responsive -->
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
<!--[if lt IE 9]><script src="https://cdnjs.cloudflare.com/ajax/libs/html5shiv/3.7.3/html5shiv.js"></script><![endif]-->
<!--[if lt IE 9]><script src="js/respond.js"></script><![endif]-->
</head>

<body>

<div class="page-wrapper">

    <!-- Preloader -->
    <div class="preloader"></div>

    <!-- Main Header -->
    <header class="main-header header-style-two">
    	<!-- Header Top-->
    	<div class="header-top style-two">
        	<div class="auto-container">
            	<div class="clearfix">

                    <!--Top Left-->
                    <div class="top-left top-links">
                    	<ul class="clearfix">
                        	<li><a href="#"><span class="icon fa fa-globe"></span> hmsi.telkomuniversity.ac.id </a></li>
                            <li><a href="#"><span class="icon fa fa-envelope-o"></span> ristek_hmsi@gmail.com</a></li>
                        </ul>
                    </div>

                    <!--Top Right-->
                    <div class="top-right">
                    	<div class="social-icon">
                            <a href="#"><span class="fa fa-facebook"></span></a>
                            <a href="#"><span class="fa fa-twitter"></span></a>
                            <a href="#"><span class="fa fa-google-plus"></span></a>
                            <a href="#"><span class="fa fa-youtube"></span></a>
                            <a href="#"><span class="fa fa-instagram"></span></a>
                        </div>
                    </div>

                </div>

            </div>
        </div>
        <!-- Header Top One End -->

        <!-- Header Lower -->
        <div class="header-lower">
            <div class="main-box">
                <div class="auto-container">
                    <div class="outer-container clearfix">
                        <!--Logo Box-->
                        <div class="logo-box">
                            <div class="logo"><a href="/todo"><img src="images/logo-2.png" alt=""></a></div>
                        </div>

                        <!--Nav Outer-->
                        <div class="nav-outer clearfix">
                            <!-- Main Menu -->
                            <nav class="main-menu">
                                <div class="navbar-header">
                                    <!-- Toggle Button -->
                                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                    </button>
                                </div>

                                <div class="navbar-collapse collapse clearfix">
                                    <ul class="navigation clearfix">


                                        {{-- <li><a href="/todo">BERANDA</a></li> --}}
                                        <li class="dropdown"><a href="/hmsi">HMSI</a>
                                            <ul>
                                                <li><a class="scroll-to-target" href="/hmsi#sejarah">Sejarah</a></li>
                                                <li><a class="scroll-to-target" href="/hmsi#visimisi">Visi dan Misi</a></li>
                                                <li><a class="scroll-to-target" href="/hmsi#strukturorganisasi">Struktur Organisasi</a></li>
                                                <li class="dropdown"><a scroll-to-target" href="/hmsi#departemenbiro">Departement dan Biro</a>
                                                    <ul>
                                                        <li><a href="/kaderisasi">Kaderisasi</a></li>
                                                        <li><a href="/ristek">Riset dan Teknologi</a></li>
                                                        <li><a href="/kemahasiswaan">Kemahasiswaan</a></li>
                                                        <li><a href="/hrd">Human Resources Development</a></li>
                                                        <li><a href="/epr">Enterpreneur</a></li>
                                                        <li><a href="/kominfo">Komunikasi dan Informasi</a></li>
                                                        <li><a href="/akademik">Akademik</a></li>
                                                        <li><a href="/dm">Dedikasi Masyarakat</a></li>
                                                        <li><a href="/relasi">Relasi</a></li>
                                                    </ul>
                                                </li>
                                            </ul>
                                        </li>


                                        <li class=" dropdown"><a href="/laboratorium/beranda">LABORATORIUM</a>
                                            <ul>
                                                <li><a href="/laboratorium/sisjar">SISJAR</a></li>
                                                <li><a href="/laboratorium/prodase">PRODASE</a></li>
                                                <li><a href="/laboratorium/erp">ERP</a></li>
                                                <li><a href="/laboratorium/bpad">BPAD</a></li>
                                            </ul>
                                        </li>

                                        <li class=" dropdown"><a href="/keprofesian/beranda">KEPROFESIAN</a>
                                            <ul>
                                                <li><a href="/keprofesian/elc">ERP Laboratory Club</a></li>
                                                <li><a href="/keprofesian/blc">BPAD Laboratory Club</a></li>
                                            </ul>
                                        </li>


                                        <li class=" dropdown"><a href="/event/beranda">EVENT</a>
                                            <ul>
                                                <li><a href="/event/agenda">AGENDA</a></li>
                                                <li><a href="/event/galery">GALERI</a></li>
                                            </ul>
                                        </li>

                                        <li><a href="/tokohmsi">TOKO HMSI</a></li>


                                        <li><a href="/hubungikami">HUBUNGI KAMI</a></li>
                                     </ul>
                                </div>
                            </nav><!-- Main Menu End-->

                            <!--Button Outer-->
                            <div class="btn-outer">

                                <div class="dropdown">
                                    <button class="search-box-btn dropdown-toggle" type="button" id="dropdownMenu3" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><span class="fa fa-search"></span></button>
                                    <ul class="dropdown-menu pull-right search-panel" aria-labelledby="dropdownMenu3">
                                        <li class="panel-outer">
                                            <div class="form-container">
                                                <form method="post" action="http://t.commonsupport.com/torino/blog.html">
                                                    <div class="form-group">
                                                        <input type="search" name="field-name" value="" placeholder="Search Here" required="">
                                                        <button type="submit" class="search-btn"><span class="fa fa-search"></span></button>
                                                    </div>
                                                </form>
                                            </div>
                                        </li>
                                    </ul>
                                </div>

                            	{{-- <a href="contact.html" class="theme-btn btn-style-four">Buy Tickets</a> --}}
                            </div>

                        </div><!--Nav Outer End-->

                    </div>
                </div>
            </div>
        </div>

        <!--Sticky Header-->
        <div class="sticky-header">
            <div class="auto-container clearfix">
                <!--Logo-->
                <div class="logo pull-left">
                    <a href="index-2.html" class="img-responsive"><img src="images/logo-small.png" alt="" title=""></a>
                </div>

                <!--Right Col-->
                <div class="right-col pull-right">
                    <!-- Main Menu -->
                    <nav class="main-menu">
                        <div class="navbar-header">
                            <!-- Toggle Button -->
                            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            </button>
                        </div>

                        <div class="navbar-collapse collapse clearfix">
                            <ul class="navigation clearfix">
                                        {{-- <li><a href="/todo">BERANDA</a></li> --}}
                                        <li class="dropdown"><a href="/hmsi">HMSI</a>
                                            <ul>
                                                <li><a class="scroll-to-target" href="/hmsi#sejarah">Sejarah</a></li>
                                                <li><a class="scroll-to-target" href="/hmsi#visimisi">Visi dan Misi</a></li>
                                                <li><a class="scroll-to-target" href="/hmsi#strukturorganisasi">Struktur Organisasi</a></li>
                                                <li class="dropdown"><a scroll-to-target" href="/hmsi#departemenbiro">Departement dan Biro</a>
                                                    <ul>
                                                        <li><a href="/kaderisasi">Kaderisasi</a></li>
                                                        <li><a href="/ristek">Riset dan Teknologi</a></li>
                                                        <li><a href="/kemahasiswaan">Kemahasiswaan</a></li>
                                                        <li><a href="/hrd">Human Resources Development</a></li>
                                                        <li><a href="/epr">Enterpreneur</a></li>
                                                        <li><a href="/kominfo">Komunikasi dan Informasi</a></li>
                                                        <li><a href="/akademik">Akademik</a></li>
                                                        <li><a href="/dm">Dedikasi Masyarakat</a></li>
                                                        <li><a href="/relasi">Relasi</a></li>
                                                    </ul>
                                                </li>
                                            </ul>
                                        </li>


                                        <li class=" dropdown"><a href="/laboratorium/beranda">LABORATORIUM</a>
                                            <ul>
                                                <li><a href="/sisjar">SISJAR</a></li>
                                                <li><a href="/prodase">PRODASE</a></li>
                                                <li><a href="/erp">ERP</a></li>
                                                <li><a href="/bpad">BPAD</a></li>
                                            </ul>
                                        </li>

                                        <li class=" dropdown"><a href="/keprofesian/beranda">KEPROFESIAN</a>
                                            <ul>
                                                <li><a href="/elc">ERP Laboratory Club</a></li>
                                                <li><a href="/blc">BPAD Laboratory Club</a></li>
                                            </ul>
                                        </li>


                                        <li class=" dropdown"><a href="/event/beranda">EVENT</a>
                                            <ul>
                                                <li><a href="/event/agenda">AGENDA</a></li>
                                                <li><a href="/event/galery">GALERI</a></li>
                                            </ul>
                                        </li>

                                        <li><a href="/tokohmsi">TOKO HMSI</a></li>


                                        <li><a href="/hubungikami">HUBUNGI KAMI</a></li>

                             </ul>
                        </div>
                    </nav><!-- Main Menu End-->
                </div>

            </div>
        </div>
        <!--End Sticky Header-->

    </header>
    <!--End Main Header -->

    
      <!--Page Title-->
    <section class="page-title" style="background-image:url(images/background/2.jpg);">
        <div class="outer-container" >
            <div class="inner-box">
                <h1>@yield('title')</h1>
            </div>
        </div>
    </section>
    <!--End Page Title-->
            


    @yield('content')

    @yield('member')





 



    <!--Main Footer-->
    <footer class="main-footer footer-style-two">
    	<div class="auto-container">



        	<!--Footer Info Section-->
        	<div class="footer-info-section">
            	<div class="row clearfix">
                	<!--Column-->
                	<div class="column col-md-4 col-sm-6 col-xs-12">
                    	<div class="footer-info">
                        	<div class="inner">
                            	<div class="icon flaticon-location-pin"></div>
                                <div class="text">
                                <b>Gedung C - Fakultas Rekayasa Industri</b><br>
                                Jl. Telekomunikasi Terusan Buah Batu<br>
                                Bandung 40257 Indonesia<br>
                                Telp: 62-22-756 4108<br>
                                Fax: 62-22 7565 930<br>
                                


                                </div>
                            </div>
                        </div>
                    </div>

                    <!--Column-->
                	<div class="column col-md-4 col-sm-6 col-xs-12">
                    	<div class="footer-info">
                        	<div class="inner">
                            	<div  class="icon fa fa-globe"></div>
                                <div class="text">hmsi.telkomuniversity.ac.id</div>
                            </div>
                        </div>
                    </div>

                    <!--Column-->
                	<div class="column col-md-4 col-sm-6 col-xs-12">
                    	<div class="footer-info">
                        	<div class="inner">
                            	<div class="icon flaticon-envelope"></div>
                                <div class="text">ristek_hmsi@gmail.com</div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>

        </div>
        <!--Footer Bottom-->
        <div class="footer-bottom">
        	<div class="auto-container">
            	<div class="row clearfix">
                	<div class="column col-md-6 col-sm-12 col-xs-12">
                    	<div class="copyright">COPYRIGHT &copy; 2017 - Departement Ristek HMSI</div>
                    </div>
                    <div class="column col-md-6 col-sm-12 col-xs-12">
                    	<ul class="social-icon-four">
                            <li><a href="#"><span class="fa fa-facebook"></span></a></li>
                            <li><a href="#"><span class="fa fa-twitter"></span></a></li>
                            <li><a href="#"><span class="fa fa-instagram"></span></a></li>
                            <li><a href="#"><span class="fa fa-google-plus"></span></a></li>
                            <li><a href="#"><span class="fa fa-linkedin"></span></a></li>
                            <li><a href="#"><span class="fa fa-pinterest-p"></span></a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!--End Main Footer-->

</div>
<!--End pagewrapper-->

<!--Scroll to top-->
<div class="scroll-to-top scroll-to-target" data-target=".main-header"><span class="icon fa fa-long-arrow-up"></span></div>




<script src="/js/jquery.js"></script>
<script src="/js/bootstrap.min.js"></script>
<script src="/js/revolution.min.js"></script>
<script src="/js/jquery-ui.js"></script>
<script src="/js/jquery.fancybox.pack.js"></script>
<script src="/js/jquery.fancybox-media.js"></script>
<script src="/js/owl.js"></script>
<script src="/js/wow.js"></script>
<script src="/js/appear.js"></script>
<script src="/js/jquery.countdown.js"></script>
<script src="/js/script.js"></script>

<!--Color Switcher Script-->
<script src="js/color-settings.js"></script>
</body>

<!-- Mirrored from t.commonsupport.com/torino/index-2.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 08 Aug 2017 12:39:48 GMT -->
</html>
